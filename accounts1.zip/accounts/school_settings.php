<?php
session_start();

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'], true)) {
    header("Location: login.php");
    exit();
}

try {
    require_once __DIR__ . '/includes/db.php';
} catch (Throwable $e) {
    error_log('School settings bootstrap error: ' . $e->getMessage());
    $_SESSION['error'] = 'Database connection failed. Please contact the administrator.';
    header("Location: login.php");
    exit();
}

$message = "";
$role = $_SESSION['role'];
$isAdmin = $role === 'admin';
$isAccountant = $role === 'accountant';
$logoWebPath = '/storage/logos/school-1.png';
$logoFilePath = dirname(__DIR__) . $logoWebPath;

function showMessage(string $type, string $text): string {
    return "<div class='alert alert-{$type} border-0 shadow-sm'>{$text}</div>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'update_settings') {
            if (!$isAdmin) {
                throw new RuntimeException('Only admin users can update school settings.');
            }

            $name = trim($_POST['name'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $bank = trim($_POST['bank_name'] ?? '');
            $acc_name = trim($_POST['account_name'] ?? '');
            $acc_no = trim($_POST['account_no'] ?? '');

            if ($name === '') {
                throw new RuntimeException('School name is required.');
            }

            if (!empty($_FILES['logo']['name'])) {
                $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                $mimeType = mime_content_type($_FILES['logo']['tmp_name']);

                if (!in_array($mimeType, $allowedTypes, true)) {
                    throw new RuntimeException('Logo must be a JPG, PNG, GIF, or WEBP image.');
                }

                $logoDir = dirname($logoFilePath);
                if (!is_dir($logoDir) && !mkdir($logoDir, 0755, true)) {
                    throw new RuntimeException('Could not create logo upload directory.');
                }

                if (!move_uploaded_file($_FILES['logo']['tmp_name'], $logoFilePath)) {
                    throw new RuntimeException('Logo upload failed.');
                }
            }

            $stmt = $pdo->prepare("
                UPDATE school_info
                SET name = ?, address = ?, phone = ?, email = ?, logo = ?,
                    bank_name = ?, account_name = ?, account_no = ?
                LIMIT 1
            ");
            $stmt->execute([$name, $address, $phone, $email, $logoWebPath, $bank, $acc_name, $acc_no]);
            $message = showMessage('success', 'Settings updated successfully.');
        }

        if ($action === 'create_accountant') {
            if (!$isAdmin) {
                throw new RuntimeException('Only admin users can create accountant accounts.');
            }

            $fullName = trim($_POST['accountant_full_name'] ?? '');
            $accountantEmail = trim(filter_var($_POST['accountant_email'] ?? '', FILTER_SANITIZE_EMAIL));
            $password = trim($_POST['accountant_password'] ?? '');
            $schoolId = (int)($_POST['school_id'] ?? 1);

            if ($fullName === '' || $accountantEmail === '' || $password === '') {
                throw new RuntimeException('Full name, email, and password are required.');
            }

            if (!filter_var($accountantEmail, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('Enter a valid accountant email address.');
            }

            if (strlen($password) < 6) {
                throw new RuntimeException('Password must be at least 6 characters.');
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);