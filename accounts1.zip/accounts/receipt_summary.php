<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

$student_id = $_GET['student_id'] ?? 0;
$bill_id    = $_GET['bill_id'] ?? 0; 
$session_id = $_GET['session_id'] ?? 0; 
$term_id    = $_GET['term_id'] ?? 0;    

if (!$student_id) {
    die("Invalid Request: Student ID is required.");
}

/**
 * Helper function to convert numeric term_id to string
 */
function getTermName($id) {
    return match((int)$id) {
        1 => 'First Term',
        2 => 'Second Term',
        3 => 'Third Term',
        default => 'N/A'
    };
}

try {
    // 1. Fetch Student & Current Class Details
    $stmt_s = $pdo->prepare("
        SELECT s.*, c.name as current_class_name 
        FROM students s 
        JOIN classes c ON s.class_id = c.id 
        WHERE s.id = ?");
    $stmt_s->execute([$student_id]);
    $student = $stmt_s->fetch();

    if (!$student) die("Student not found.");

    // 2. Build Query for Bills using term_activation logic
    // We join term_activation to check status if necessary, but term_id comes from student_bills
    $bill_query = "SELECT sb.*, sess.name as session_name, c.name as bill_class_name 
                   FROM student_bills sb
                   LEFT JOIN sessions sess ON sb.session_id = sess.id
                   LEFT JOIN students s ON sb.student_id = s.id
                   LEFT JOIN classes c ON s.class_id = c.id
                   WHERE sb.student_id = ?";
    $bill_params = [$student_id];

    if ($bill_id) {
        $bill_query .= " AND sb.id = ?";
        $bill_params[] = $bill_id;
    } elseif ($session_id && $term_id) {
        $bill_query .= " AND sb.session_id = ? AND sb.term_id = ?";
        $bill_params[] = $session_id;
        $bill_params[] = $term_id;
    }
    
    $stmt_bills = $pdo->prepare($bill_query);
    $stmt_bills->execute($bill_params);
    $bills = $stmt_bills->fetchAll();

    // 3. Fetch Payment History
    $pay_query = "SELECT p.*, sb.item_name 
                  FROM payments p
                  JOIN student_bills sb ON p.bill_id = sb.id
                  WHERE p.student_id = ?";
    $pay_params = [$student_id];

    if ($bill_id) {
        $pay_query .= " AND p.bill_id = ?";
        $pay_params[] = $bill_id;
    } elseif ($session_id && $term_id) {
        $pay_query .= " AND sb.session_id = ? AND sb.term_id = ?";
        $pay_params[] = $session_id;
        $pay_params[] = $term_id;
    }
    $pay_query .= " ORDER BY p.payment_date DESC";
    
    $stmt_pay = $pdo->prepare($pay_query);
    $stmt_pay->execute($pay_params);
    $payments = $stmt_pay->fetchAll();

    // 4. Global Financial Totals
    $stmt_totals = $pdo->prepare("
        SELECT 
            SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END) as total_debt,
            SUM(CASE WHEN balance < 0 THEN ABS(balance) ELSE 0 END) as total_credit
        FROM student_bills WHERE student_id = ?");
    $stmt_totals->execute([$student_id]);
    $totals = $stmt_totals->fetch();

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Statement_<?= htmlspecialchars($student['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: #f4f7f6; font-family: 'Courier New', Courier, monospace; }
        .receipt-card { background: white; max-width: 900px; margin: 30px auto; padding: 40px; border: 1px solid #ddd; }
        .school-name { font-size: 1.8rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; }
        .line { border-top: 1px dashed #000; margin: 15px 0; }
        .balance-box { border: 1px solid #000; padding: 15px; margin-top: 20px; }
        @media print { 
            .no-print { display: none; } 
            body { background: white; } 
            .receipt-card { border: none; margin: 0; max-width: 100%; } 
        }
    </style>
</head>
<body>

<div class="no-print text-center mt-3 mb-3">
    <button onclick="window.print()" class="btn btn-primary btn-sm px-4">
        <i class="bi bi-printer me-2"></i>Print Statement
    </button>
    <a href="payments.php?search=<?= urlencode($student['admission_no']) ?>" class="btn btn-secondary btn-sm px-4">
        <i class="bi bi-arrow-left me-2"></i>Back to Profile
    </a>
    <a href="receipt_summary.php?student_id=<?= $student_id ?>" class="btn btn-info btn-sm px-4 text-white">
        <i class="bi bi-clock-history me-2"></i>Full Account History
    </a>
</div>

<div class="receipt-card">
    <div class="text-center">
        <img src="../public/uploads/school_logo.png" style="height: 80px; margin-bottom: 10px;" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
        <div class="school-name">BGB Group of Schools</div>
        <p class="mb-0 fw-bold text-uppercase">
            <?php 
                if($bill_id) echo "Single Fee Payment Receipt";
                elseif($session_id) echo "Termly Settlement Summary";
                else echo "Complete Student Ledger Statement";
            ?>
        </p>
        <p class="small text-muted">Generated: <?= date('d M, Y | H:i') ?></p>
    </div>
    
    <div class="line"></div>
    
    <div class="row small">
        <div class="col-7">
            <p class="mb-1"><strong>STUDENT:</strong> <?= htmlspecialchars($student['name']) ?></p>
            <p class="mb-1"><strong>ADM NO :</strong> <?= htmlspecialchars($student['admission_no']) ?></p>
            <p class="mb-1"><strong>CURRENT CLASS:</strong> <?= htmlspecialchars($student['current_class_name']) ?></p>
        </div>
        <div class="col-5 text-end">
            <p class="mb-1"><strong>TOTAL DEBT  :</strong> ₦<?= number_format($totals['total_debt'] ?? 0, 2) ?></p>
            <p class="mb-1"><strong>TOTAL CREDIT:</strong> ₦<?= number_format($totals['total_credit'] ?? 0, 2) ?></p>
        </div>
    </div>
    
    <div class="line"></div>
    
    <h6 class="fw-bold small mb-2 text-uppercase">Financial Breakdown</h6>
    <div class="table-responsive">
        <table class="table table-bordered table-sm small">
            <thead class="bg-light">
                <tr class="text-center">
                    <th>Fee Description</th>
                    <th>Class</th>
                    <th>Session</th>
                    <th>Term</th>
                    <th class="text-end">Bill</th>
                    <th class="text-end">Paid</th>
                    <th class="text-end">Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($bills as $b): ?>
                <tr>
                    <td class="fw-bold"><?= htmlspecialchars($b['item_name']) ?></td>
                    <td class="text-center"><?= htmlspecialchars($b['bill_class_name'] ?? 'N/A') ?></td>
                    <td class="text-center"><?= htmlspecialchars($b['session_name'] ?? 'N/A') ?></td>
                    <td class="text-center"><?= getTermName($b['term_id']) ?></td>
                    <td class="text-end">₦<?= number_format($b['total_amount'], 2) ?></td>
                    <td class="text-end">₦<?= number_format($b['paid_amount'], 2) ?></td>
                    <td class="text-end fw-bold">
                        <?php 
                            if($b['balance'] > 0) echo '<span class="text-danger">-₦'.number_format($b['balance'], 2).'</span>';
                            elseif($b['balance'] < 0) echo '<span class="text-success">₦'.number_format(abs($b['balance']), 2).'</span>';
                            else echo '<span class="text-primary">0.00</span>';
                        ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <h6 class="fw-bold small mb-2 mt-4 text-uppercase">Detailed Payment Log</h6>
    <table class="table table-sm small">
        <thead>
            <tr class="border-bottom">
                <th>Date</th>
                <th>Fee Item</th>
                <th>Ref No.</th>
                <th>Method</th>
                <th class="text-end">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!$payments): ?>
                <tr><td colspan="5" class="text-center py-2 italic">No payment transactions recorded for this selection.</td></tr>
            <?php else: ?>
                <?php foreach($payments as $p): ?>
                <tr>
                    <td><?= date('d/m/y', strtotime($p['payment_date'])) ?></td>
                    <td><?= htmlspecialchars($p['item_name']) ?></td>
                    <td><?= htmlspecialchars($p['reference_no']) ?></td>
                    <td><?= htmlspecialchars($p['payment_method']) ?></td>
                    <td class="text-end fw-bold">₦<?= number_format($p['amount_paid'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="line"></div>

    <div class="row g-2 text-center">
        <div class="col-6">
            <div class="balance-box">
                <p class="small mb-0 text-uppercase fw-bold text-danger">Outstanding Balance (Owed)</p>
                <h4 class="fw-bold mb-0 text-danger">- ₦<?= number_format($totals['total_debt'] ?? 0, 2) ?></h4>
            </div>
        </div>
        <div class="col-6">
            <div class="balance-box">
                <p class="small mb-0 text-uppercase fw-bold text-success">Advance Credit (Balance)</p>
                <h4 class="fw-bold mb-0 text-success">₦<?= number_format($totals['total_credit'] ?? 0, 2) ?></h4>
            </div>
        </div>
    </div>
    
    <div class="text-center mt-5">
        <p class="small text-muted italic" style="font-size: 0.7rem;">
            *** End of Statement ***<br>
            BGB Group of Schools - Accounts Department<br>
            Official Stamp Required for Physical Authentication.
        </p>
    </div>
</div>

</body>
</html>