<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant', 'super_admin'])) {
    header("Location: login.php");
    exit();
}
require_once '../config/db.php';

$message = "";

// Handle Add New Item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item'])) {
    $item_name = trim($_POST['item_name']);
    $category = $_POST['category'];
    $initial_stock = (int)$_POST['initial_stock'];
    $unit_price = (float)$_POST['unit_price'];
    $reorder_level = (int)$_POST['reorder_level'];
    
    try {
        $stmt = $pdo->prepare("INSERT INTO inventory (item_name, category, quantity_in_stock, unit_price, reorder_level, last_restock) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$item_name, $category, $initial_stock, $unit_price, $reorder_level]);
        $message = "<div class='alert alert-success'>Item '$item_name' added successfully!</div>";
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

// Handle Restock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['restock'])) {
    $item_id = (int)$_POST['item_id'];
    $quantity = (int)$_POST['quantity'];
    $cost_price = (float)$_POST['cost_price'];
    
    try {
        $pdo->beginTransaction();
        
        // Update inventory stock
        $stmt = $pdo->prepare("UPDATE inventory SET quantity_in_stock = quantity_in_stock + ?, last_restock = NOW(), last_cost_price = ? WHERE id = ?");
        $stmt->execute([$quantity, $cost_price, $item_id]);
        
        // Log the restock
        $log = $pdo->prepare("INSERT INTO inventory_logs (item_id, action, quantity, cost_price, recorded_by) VALUES (?, 'restock', ?, ?, ?)");
        $log->execute([$item_id, $quantity, $cost_price, $_SESSION['user_id']]);
        
        $pdo->commit();
        $message = "<div class='alert alert-success'>Stock updated successfully!</div>";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $message = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

// Handle Sell/Deduct Stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sell'])) {
    $item_id = (int)$_POST['item_id'];
    $quantity = (int)$_POST['sell_quantity'];
    
    try {
        // Check current stock
        $check = $pdo->prepare("SELECT quantity_in_stock FROM inventory WHERE id = ?");
        $check->execute([$item_id]);
        $current = $check->fetchColumn();
        
        if ($current < $quantity) {
            $message = "<div class='alert alert-warning'>Insufficient stock! Only $current available.</div>";
        } else {
            $pdo->beginTransaction();
            
            // Update inventory stock
            $stmt = $pdo->prepare("UPDATE inventory SET quantity_in_stock = quantity_in_stock - ? WHERE id = ?");
            $stmt->execute([$quantity, $item_id]);
            
            // Log the sale
            $log = $pdo->prepare("INSERT INTO inventory_logs (item_id, action, quantity, recorded_by) VALUES (?, 'sold', ?, ?)");
            $log->execute([$item_id, $quantity, $_SESSION['user_id']]);
            
            $pdo->commit();
            $message = "<div class='alert alert-success'>Sale recorded! Stock deducted.</div>";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        $message = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

// Fetch Inventory
try {
    $inventory = $pdo->query("SELECT * FROM inventory ORDER BY item_name ASC")->fetchAll();
} catch (PDOException $e) {
    $inventory = [];
}

// Stats
$total_items = count($inventory);
$low_stock = 0;
$total_value = 0;
foreach ($inventory as $item) {
    if ($item['quantity_in_stock'] <= $item['reorder_level']) $low_stock++;
    $total_value += $item['quantity_in_stock'] * $item['unit_price'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; z-index: 1000; overflow-y: auto; }
        .main-content { margin-left: 260px; padding: 30px; }
        .nav-link { color: #94a3b8; padding: 10px 20px; border-radius: 8px; margin: 2px 15px; text-decoration: none; display: block; font-size: 0.9rem; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: white; }
        .nav-link.active { background: var(--primary-blue); color: white; }
        .menu-label { font-size: 0.7rem; font-weight: 700; color: #475569; margin: 15px 25px 5px; text-transform: uppercase; }
        .stat-card { border: none; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .low-stock { background: #fef2f2; color: #dc2626; }
        .badge-low { background: #dc2626; color: white; }
        @media (max-width: 992px) { .sidebar { left: -260px; } .main-content { margin-left: 0; } .sidebar.active { left: 0; } }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <h5 class="text-white mb-0">School<span class="text-primary">RMS</span></h5>
        <small class="text-muted">Inventory Module</small>
    </div>
    <nav class="nav flex-column mb-5">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        
        <div class="menu-label">Finance & Store</div>
        <a class="nav-link" href="sales.php"><i class="bi bi-cart-check me-2"></i> Sales</a>
        <a class="nav-link active" href="inventory.php"><i class="bi bi-box-seam me-2"></i> Inventory</a>
        <a class="nav-link" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>
        <a class="nav-link" href="cashbook.php"><i class="bi bi-book me-2"></i> Cashbook</a>
        
        <div class="menu-label">Administration</div>
        <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <?= $message ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1"><i class="bi bi-box-seam me-2"></i>Inventory Management</h3>
            <p class="text-muted mb-0">Track stock levels and manage store inventory.</p>
        </div>
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#addItemModal">
            <i class="bi bi-plus-lg me-2"></i> Add New Item
        </button>
    </div>

    <!-- Stats -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card stat-card p-4">
                <small class="text-muted text-uppercase fw-bold">Total Items</small>
                <h2 class="fw-bold mb-0"><?= $total_items ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card p-4 <?= $low_stock > 0 ? 'low-stock' : '' ?>">
                <small class="text-muted text-uppercase fw-bold">Low Stock Items</small>
                <h2 class="fw-bold mb-0"><?= $low_stock ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card p-4">
                <small class="text-muted text-uppercase fw-bold">Total Stock Value</small>
                <h2 class="fw-bold mb-0">₦<?= number_format($total_value, 2) ?></h2>
            </div>
        </div>
    </div>

    <!-- Inventory Table -->
    <div class="card stat-card p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold mb-0">Current Stock</h6>
            <span class="badge bg-secondary"><?= $total_items ?> items</span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Current Stock</th>
                        <th>Reorder Level</th>
                        <th>Unit Price</th>
                        <th>Stock Value</th>
                        <th>Last Restock</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($inventory)): ?>
                        <tr><td colspan="8" class="text-center py-5 text-muted">
                            <i class="bi bi-box-seam display-4 opacity-25"></i>
                            <p class="mt-2">No items in inventory. Click "Add New Item" to start.</p>
                        </td></tr>
                    <?php endif; ?>
                    <?php foreach ($inventory as $item): ?>
                        <?php $is_low = $item['quantity_in_stock'] <= $item['reorder_level']; ?>
                        <tr class="<?= $is_low ? 'table-danger' : '' ?>">
                            <td class="fw-bold"><?= htmlspecialchars($item['item_name']) ?></td>
                            <td><span class="badge bg-light text-dark"><?= htmlspecialchars($item['category']) ?></span></td>
                            <td>
                                <?php if ($is_low): ?>
                                    <span class="badge badge-low"><?= $item['quantity_in_stock'] ?></span>
                                <?php else: ?>
                                    <?= $item['quantity_in_stock'] ?>
                                <?php endif; ?>
                            </td>
                            <td><?= $item['reorder_level'] ?></td>
                            <td>₦<?= number_format($item['unit_price'], 2) ?></td>
                            <td class="fw-bold">₦<?= number_format($item['quantity_in_stock'] * $item['unit_price'], 2) ?></td>
                            <td><small><?= $item['last_restock'] ? date('d M, Y', strtotime($item['last_restock'])) : 'Never' ?></small></td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#restockModal<?= $item['id'] ?>">
                                    <i class="bi bi-plus-circle"></i> Restock
                                </button>
                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#sellModal<?= $item['id'] ?>">
                                    <i class="bi bi-cart-dash"></i> Sell
                                </button>
                            </td>
                        </tr>
                        
                        <!-- Restock Modal -->
                        <div class="modal fade" id="restockModal<?= $item['id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <form class="modal-content" method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Restock: <?= htmlspecialchars($item['item_name']) ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Current Stock: <strong><?= $item['quantity_in_stock'] ?></strong></p>
                                        <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                                        <div class="mb-3">
                                            <label class="form-label">Quantity to Add</label>
                                            <input type="number" name="quantity" class="form-control" min="1" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Cost Price per Unit (₦)</label>
                                            <input type="number" name="cost_price" class="form-control" step="0.01" value="<?= $item['unit_price'] ?>" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" name="restock" class="btn btn-success">Add Stock</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        <!-- Sell Modal -->
                        <div class="modal fade" id="sellModal<?= $item['id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <form class="modal-content" method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Sell: <?= htmlspecialchars($item['item_name']) ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Available Stock: <strong><?= $item['quantity_in_stock'] ?></strong></p>
                                        <p>Selling Price: <strong>₦<?= number_format($item['unit_price'], 2) ?></strong></p>
                                        <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                                        <div class="mb-3">
                                            <label class="form-label">Quantity to Sell</label>
                                            <input type="number" name="sell_quantity" class="form-control" min="1" max="<?= $item['quantity_in_stock'] ?>" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" name="sell" class="btn btn-primary">Record Sale</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" method="POST">
            <div class="modal-header">
                <h5 class="modal-title">Add New Inventory Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Item Name</label>
                    <input type="text" name="item_name" class="form-control" placeholder="e.g., Blue Blazer Size 6" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select">
                        <option value="Uniform">Uniform</option>
                        <option value="Books">Books</option>
                        <option value="Stationery">Stationery</option>
                        <option value="Sports">Sports Equipment</option>
                        <option value="Bags">Bags</option>
                        <option value="Shoes">Shoes</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Initial Stock Qty</label>
                        <input type="number" name="initial_stock" class="form-control" min="0" value="0" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Unit Price (₦)</label>
                        <input type="number" name="unit_price" class="form-control" step="0.01" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Reorder Level (Low Stock Alert)</label>
                    <input type="number" name="reorder_level" class="form-control" min="0" value="5">
                    <small class="text-muted">You'll be alerted when stock falls below this level.</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="add_item" class="btn btn-primary">Add Item</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
