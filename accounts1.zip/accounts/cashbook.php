<?php
// 1. Enable full error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

// Branding
$school = $pdo->query("SELECT name FROM school_info LIMIT 1")->fetch();
$school_name = $school['name'] ?? 'SchoolRMS';

// 1. Get Unique Categories for the Filter
try {
    $cat_query = "SELECT DISTINCT category FROM unified_cashbook WHERE category IS NOT NULL AND category != '' ORDER BY category ASC";
    $all_categories = $pdo->query($cat_query)->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) { $all_categories = []; }

// 2. Handle Filters
$start_date   = $_GET['start_date'] ?? date('Y-m-01');
$end_date     = $_GET['end_date'] ?? date('Y-m-d');
$filter_cat   = $_GET['category'] ?? 'all';
$filter_type  = $_GET['type'] ?? 'all'; 
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

// 3. Fetch Records with Filter Logic (Strictly using unified_cashbook columns)
try {
    $sql = "SELECT * FROM unified_cashbook WHERE DATE(date) BETWEEN ? AND ?";
    $params = [$start_date, $end_date];

    // Category Filter
    if ($filter_cat !== 'all') {
        $sql .= " AND category = ?";
        $params[] = $filter_cat;
    }

    // Type Filter
    if ($filter_type !== 'all') {
        $sql .= " AND type = ?";
        $params[] = $filter_type;
    }
    
    // Search Box Logic (Targeting ref_no and details)
    if ($search_query !== '') {
        $searchTerm = "%$search_query%";
        $sql .= " AND (
            ref_no LIKE ? 
            OR details LIKE ? 
            OR category LIKE ? 
            OR method LIKE ?
        )";
        for($i=0; $i<4; $i++) { $params[] = $searchTerm; }
    }
    
    $sql .= " ORDER BY date DESC, id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $records = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

// 4. Calculate Balances
$total_income = 0; $total_expense = 0;
$cash_balance = 0; $bank_balance = 0;

foreach ($records as $r) {
    $amt = (float)$r['amount'];
    $method = strtolower($r['method'] ?? '');
    if ($r['type'] == 'Income') {
        $total_income += $amt;
        if (strpos($method, 'cash') !== false) $cash_balance += $amt;
        else $bank_balance += $amt;
    } else {
        $total_expense += $amt;
        if (strpos($method, 'cash') !== false) $cash_balance -= $amt;
        else $bank_balance -= $amt;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cashbook Ledger | <?= htmlspecialchars($school_name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; font-size: 0.85rem; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; overflow-y: auto; z-index: 1000; }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .nav-link { color: #94a3b8; padding: 10px 20px; border-radius: 8px; margin: 2px 15px; text-decoration: none; display: block; }
        .nav-link.active { background: var(--primary-blue); color: white; }
        .badge-income { background: #dcfce7; color: #166534; }
        .badge-expense { background: #fee2e2; color: #991b1b; }
        .metric-label { font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; }
        .tfoot-bg { background: #f1f5f9; font-weight: bold; }
        @media (max-width: 992px) { .sidebar { display: none; } .main-content { margin-left: 0; } }
        @media print { .sidebar, .filter-section, .btn-print { display: none !important; } .main-content { margin-left: 0; padding: 0; } .card { box-shadow: none; border: 1px solid #eee; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3 text-white">
        <h6 class="fw-bold"><?= htmlspecialchars($school_name) ?></h6>
    </div>
    <nav class="nav flex-column gap-1">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link active" href="cashbook.php"><i class="bi bi-journal-text me-2"></i> Cashbook</a>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link" href="sales.php"><i class="bi bi-cart-check me-2"></i> General Sales</a>
        <a class="nav-link" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>
        <hr class="mx-3 text-secondary">
        <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4 text-dark">
        <div>
            <h3 class="fw-bold mb-0">Financial Ledger</h3>
            <p class="text-muted small">Viewing: <b><?= htmlspecialchars($filter_cat == 'all' ? 'All Categories' : $filter_cat) ?></b></p>
        </div>
        <button onclick="window.print()" class="btn btn-dark btn-sm btn-print"><i class="bi bi-printer me-2"></i>Print Report</button>
    </div>

    <div class="row g-3 mb-4 text-dark">
        <div class="col-md-3">
            <div class="card p-3 border-bottom border-primary border-4 text-center">
                <span class="metric-label">Cash on Hand</span>
                <h4 class="fw-bold mb-0">₦<?= number_format($cash_balance, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 border-bottom border-info border-4 text-center">
                <span class="metric-label">Bank Balance</span>
                <h4 class="fw-bold mb-0">₦<?= number_format($bank_balance, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 border-bottom border-danger border-4 text-center">
                <span class="metric-label">Filtered Outflow</span>
                <h4 class="fw-bold text-danger mb-0">₦<?= number_format($total_expense, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 border-bottom border-success border-4 text-center bg-light">
                <span class="metric-label">Net Filtered Position</span>
                <h4 class="fw-bold text-success mb-0">₦<?= number_format($total_income - $total_expense, 2) ?></h4>
            </div>
        </div>
    </div>

    <div class="card p-4 mb-4 filter-section">
        <form class="row g-3" method="GET" action="cashbook.php">
            <div class="col-md-2 text-dark">
                <label class="small fw-bold">From</label>
                <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($start_date) ?>">
            </div>
            <div class="col-md-2 text-dark">
                <label class="small fw-bold">To</label>
                <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($end_date) ?>">
            </div>
            <div class="col-md-2 text-dark">
                <label class="small fw-bold">Type</label>
                <select name="type" class="form-select">
                    <option value="all" <?= $filter_type == 'all' ? 'selected' : '' ?>>All Types</option>
                    <option value="Income" <?= $filter_type == 'Income' ? 'selected' : '' ?>>Income</option>
                    <option value="Expense" <?= $filter_type == 'Expense' ? 'selected' : '' ?>>Expenses</option>
                </select>
            </div>
            <div class="col-md-2 text-dark">
                <label class="small fw-bold">Category</label>
                <select name="category" class="form-select">
                    <option value="all" <?= $filter_cat == 'all' ? 'selected' : '' ?>>All Categories</option>
                    <?php foreach($all_categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>" <?= $filter_cat == $cat ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 text-dark">
                <label class="small fw-bold">Search (Ref/Details)</label>
                <input type="text" name="search" class="form-control" placeholder="Search..." value="<?= htmlspecialchars($search_query) ?>">
            </div>
            <div class="col-md-2 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-primary flex-grow-1">Filter</button>
                <a href="cashbook.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-clockwise"></i></a>
            </div>
        </form>
    </div>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light text-dark">
                    <tr>
                        <th class="ps-3 py-3">Date</th>
                        <th>Category</th>
                        <th>Transaction Particulars</th>
                        <th>Method</th>
                        <th class="text-end">Inflow (₦)</th>
                        <th class="text-end pe-3">Outflow (₦)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($records)): ?>
                        <tr><td colspan="6" class="text-center py-5 text-muted">No transactions found for these filters.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($records as $row): ?>
                    <tr>
                        <td class="ps-3 py-3 small text-muted"><?= date('d/m/Y', strtotime($row['date'])) ?></td>
                        <td>
                            <span class="badge rounded-pill <?= $row['type'] == 'Income' ? 'badge-income' : 'badge-expense' ?> p-2 px-3">
                                <?= htmlspecialchars($row['category'] ?? 'General') ?>
                            </span>
                        </td>
                        <td>
                            <div class="fw-bold text-dark">
                                <?php 
                                    // Remove Student IDs from the details string if present
                                    $clean_details = preg_replace('/Student ID:\s*\d+/i', '', $row['details'] ?? '');
                                    echo htmlspecialchars(trim($clean_details, " ,-") ?: 'Bill Payment');
                                ?>
                            </div>
                            <?php if(!empty($row['ref_no'])): ?>
                                <span class="badge bg-light text-primary border-0 p-0" style="font-size: 0.75rem;">
                                    Ref: <?= htmlspecialchars($row['ref_no']) ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-white text-dark border small fw-normal">
                                <i class="bi bi-<?= strpos(strtolower($row['method'] ?? ''), 'cash') !== false ? 'cash' : 'bank' ?> me-1"></i>
                                <?= htmlspecialchars($row['method'] ?? 'N/A') ?>
                            </span>
                        </td>
                        <td class="text-end fw-bold text-success"><?= $row['type'] == 'Income' ? number_format($row['amount'], 2) : '-' ?></td>
                        <td class="text-end fw-bold text-danger pe-3"><?= $row['type'] == 'Expense' ? number_format($row['amount'], 2) : '-' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="tfoot-bg">
                    <tr class="text-dark">
                        <td colspan="4" class="ps-3 py-3 text-uppercase">Subtotal (Filtered View)</td>
                        <td class="text-end text-success">₦<?= number_format($total_income, 2) ?></td>
                        <td class="text-end text-danger pe-3">₦<?= number_format($total_expense, 2) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
</body>
</html> 