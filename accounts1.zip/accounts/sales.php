<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant', 'super_admin'])) {
    header("Location: login.php");
    exit();
}
require_once '../config/db.php';

$message = "";
$ip_address = $_SERVER['REMOTE_ADDR'];

// Handle New Sale
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_sale'])) {
    $inventory_id = (int)$_POST['inventory_id'];
    $qty = (int)$_POST['quantity'];
    $price = (float)$_POST['unit_price'];
    $total = $qty * $price;
    $buyer = $_POST['buyer_name'] ?: 'Walking-in Customer';
    $pay_method = $_POST['payment_method'];
    $user_id = $_SESSION['user_id'];

    try {
        // Check if item exists in inventory
        $check_inv = $pdo->prepare("SELECT id, item_name, quantity_in_stock FROM inventory WHERE id = ?");
        $check_inv->execute([$inventory_id]);
        $inv_item = $check_inv->fetch();
        
        if (!$inv_item) {
            throw new Exception("This item is not in your inventory. Please add it to inventory first.");
        }
        
        // Check stock availability
        if ($inv_item['quantity_in_stock'] < $qty) {
            throw new Exception("Insufficient stock! Only " . $inv_item['quantity_in_stock'] . " available in inventory for '" . $inv_item['item_name'] . "'. Please restock or reduce quantity.");
        }

        $pdo->beginTransaction();

        // 1. Deduct from inventory
        $deduct = $pdo->prepare("UPDATE inventory SET quantity_in_stock = quantity_in_stock - ? WHERE id = ?");
        $deduct->execute([$qty, $inventory_id]);
        
        // 2. Log inventory deduction
        $log_inv = $pdo->prepare("INSERT INTO inventory_logs (item_id, action, quantity, cost_price, recorded_by) VALUES (?, 'sold', ?, ?, ?)");
        $log_inv->execute([$inventory_id, $qty, $price, $user_id]);

        // 3. Insert into sales table
        $stmt = $pdo->prepare("INSERT INTO sales (inventory_id, item_name, quantity, unit_price, total_amount, buyer_name, payment_method, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$inventory_id, $inv_item['item_name'], $qty, $price, $total, $buyer, $pay_method, $user_id]);
        
        $sale_id = $pdo->lastInsertId();

        // 4. Get placeholder student for payments
        $stmt_student = $pdo->query("SELECT id FROM students LIMIT 1");
        $placeholder_student = $stmt_student->fetchColumn();
        if (!$placeholder_student) {
            $placeholder_student = null;
        }

        // 5. Sync to payments (The source for the Cashbook)
        $ref_for_cashbook = "Sale: " . $inv_item['item_name'] . " (Qty: " . $qty . ")";
        $receipt_no = "REC-" . $sale_id;
        
        $pay_stmt = $pdo->prepare("INSERT INTO payments (payment_date, amount_paid, payment_method, reference_no, receipt_no, student_id, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $pay_stmt->execute([
            date('Y-m-d'), 
            $total, 
            $pay_method, 
            $ref_for_cashbook, 
            $receipt_no, 
            $placeholder_student,
            "Sold to: $buyer"
        ]);

        // 6. Audit log
        $audit = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
        $audit_details = "Sold: '" . $inv_item['item_name'] . "' (Qty: $qty) at ₦" . number_format($price, 2) . " each. Total: ₦" . number_format($total, 2) . ". Buyer: $buyer via $pay_method. Stock deducted from inventory.";
        $audit->execute([$user_id, 'SALE_WITH_INVENTORY', $audit_details, $ip_address]);

        $pdo->commit();
        $message = "<div class='alert alert-success shadow-sm'><i class='bi bi-check-circle-fill me-2'></i> Sale of " . $inv_item['item_name'] . " recorded! Stock deducted from inventory.</div>";
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $message = "<div class='alert alert-danger shadow-sm'><i class='bi bi-exclamation-triangle-fill me-2'></i> " . $e->getMessage() . "</div>";
    }
}

// Fetch inventory items for dropdown
try {
    $inventory_items = $pdo->query("SELECT * FROM inventory WHERE quantity_in_stock > 0 ORDER BY item_name ASC")->fetchAll();
} catch (Exception $e) {
    $inventory_items = [];
}

// Stats Calculation
$today = date('Y-m-d');
$stats = $pdo->query("SELECT COUNT(*) as count, SUM(total_amount) as revenue, SUM(quantity) as items FROM sales WHERE DATE(created_at) = '$today'")->fetch();
$sales = $pdo->query("SELECT s.*, u.full_name as staff FROM sales s LEFT JOIN users u ON s.recorded_by = u.id ORDER BY s.created_at DESC LIMIT 50")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Ledger | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: #f1f5f9; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: #0f172a; color: white; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card { border: none; border-radius: 12px; transition: transform 0.2s; }
        .stat-card { border-left: 5px solid #3b82f6; }
        .nav-link { color: #94a3b8; padding: 12px 20px; text-decoration: none; display: block; }
        .nav-link:hover, .nav-link.active { color: white; background: rgba(255,255,255,0.1); border-radius: 8px; }
        .sidebar-header { padding: 25px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <h4 class="fw-bold mb-0 text-white">School<span class="text-primary">RMS</span></h4>
        <small class="text-muted text-uppercase fw-bold" style="font-size: 0.65rem;">Accounts Department</small>
    </div>
    <nav class="nav flex-column gap-1 mt-3">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link active" href="sales.php"><i class="bi bi-cart-check me-2"></i> General Sales</a>
        <a class="nav-link" href="inventory.php"><i class="bi bi-box-seam me-2"></i> Inventory</a>
        <a class="nav-link" href="cashbook.php"><i class="bi bi-book me-2"></i> Cashbook</a>
        <a class="nav-link" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>
        <hr class="mx-3 text-secondary">
        <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1"><i class="bi bi-cart-check me-2"></i>Sales & Inventory</h3>
            <p class="text-muted mb-0 small">Sales automatically deduct from inventory stock.</p>
        </div>
        <div>
            <a href="inventory.php" class="btn btn-outline-primary px-3 me-2">
                <i class="bi bi-box-seam me-1"></i> Manage Inventory
            </a>
            <button class="btn btn-primary px-4 py-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#saleModal">
                <i class="bi bi-plus-lg me-1"></i> New Sale
            </button>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card stat-card p-3 shadow-sm">
                <small class="text-muted text-uppercase fw-bold">Today's Revenue</small>
                <h2 class="fw-bold text-primary mb-0">₦<?= number_format($stats['revenue'] ?? 0, 2) ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card p-3 shadow-sm" style="border-left-color: #10b981;">
                <small class="text-muted text-uppercase fw-bold">Transactions</small>
                <h2 class="fw-bold text-success mb-0"><?= $stats['count'] ?> Sales</h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card stat-card p-3 shadow-sm" style="border-left-color: #f59e0b;">
                <small class="text-muted text-uppercase fw-bold">Items Sold</small>
                <h2 class="fw-bold text-warning mb-0"><?= $stats['items'] ?? 0 ?> Units</h2>
            </div>
        </div>
    </div>

    <?= $message ?>

    <div class="card shadow-sm mt-3">
        <div class="card-header bg-white py-3 border-0 d-flex justify-content-between">
            <h6 class="mb-0 fw-bold"><i class="bi bi-clock-history me-2 text-primary"></i>Recent Transactions</h6>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4">Date/Time</th>
                        <th>Item Description</th>
                        <th>Buyer</th>
                        <th>Qty</th>
                        <th>Total Amount</th>
                        <th>Staff</th>
                        <th class="text-center">Receipt</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($sales)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">No sales found. Record your first sale!</td></tr>
                    <?php endif; ?>
                    <?php foreach ($sales as $sale): ?>
                    <tr>
                        <td class="ps-4 small text-muted"><?= date('d M, Y | H:i', strtotime($sale['created_at'])) ?></td>
                        <td class="fw-bold"><?= htmlspecialchars($sale['item_name']) ?></td>
                        <td><?= htmlspecialchars($sale['buyer_name']) ?></td>
                        <td><?= $sale['quantity'] ?></td>
                        <td class="fw-bold text-success">₦<?= number_format($sale['total_amount'], 2) ?></td>
                        <td class="small"><?= htmlspecialchars($sale['staff'] ?? 'Admin') ?></td>
                        <td class="text-center">
                            <button onclick="printReceipt(<?= $sale['id'] ?>)" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-printer"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="saleModal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content border-0 shadow" method="POST">
            <div class="modal-header">
                <h5 class="modal-title fw-bold"><i class="bi bi-cart-plus me-2"></i>Process New Sale</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <?php if (empty($inventory_items)): ?>
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>No items in inventory!</strong><br>
                        Please <a href="inventory.php" class="alert-link">add items to inventory</a> first before recording sales.
                    </div>
                <?php else: ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Select Item from Inventory <span class="text-danger">*</span></label>
                        <select name="inventory_id" id="inventorySelect" class="form-select" required onchange="updatePrice()">
                            <option value="">-- Select an item --</option>
                            <?php foreach ($inventory_items as $inv): ?>
                                <option value="<?= $inv['id'] ?>" data-price="<?= $inv['unit_price'] ?>" data-stock="<?= $inv['quantity_in_stock'] ?>">
                                    <?= htmlspecialchars($inv['item_name']) ?> - Stock: <?= $inv['quantity_in_stock'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="item_name" id="hiddenItemName">
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Quantity <span class="text-danger">*</span></label>
                            <input type="number" name="quantity" id="quantityInput" class="form-control" value="1" min="1" required onchange="checkStock()">
                            <small id="stockAlert" class="text-muted"></small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small">Selling Price (₦) <span class="text-danger">*</span></label>
                            <input type="number" name="unit_price" id="priceInput" class="form-control" placeholder="0.00" step="0.01" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Customer Name</label>
                        <input type="text" name="buyer_name" class="form-control" placeholder="Parent or Walking-in customer">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">Payment Mode</label>
                        <select name="payment_method" class="form-select">
                            <option value="Cash">Cash</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="POS">POS</option>
                        </select>
                    </div>
                    <div class="alert alert-info mb-0">
                        <small><i class="bi bi-info-circle me-1"></i> Stock will be automatically deducted from inventory after sale.</small>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer border-0">
                <?php if (!empty($inventory_items)): ?>
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="record_sale" class="btn btn-success px-4 py-2 fw-bold shadow">
                        <i class="bi bi-check-circle me-1"></i> Record Sale
                    </button>
                <?php else: ?>
                    <a href="inventory.php" class="btn btn-primary w-100">
                        <i class="bi bi-plus-circle me-1"></i> Go to Inventory to Add Items
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<script>
function updatePrice() {
    const select = document.getElementById('inventorySelect');
    const priceInput = document.getElementById('priceInput');
    const stockAlert = document.getElementById('stockAlert');
    const qtyInput = document.getElementById('quantityInput');
    
    const selected = select.options[select.selectedIndex];
    if (selected.value) {
        const price = selected.dataset.price;
        const stock = selected.dataset.stock;
        priceInput.value = price;
        qtyInput.max = stock;
        qtyInput.placeholder = 'Max: ' + stock;
        stockAlert.innerHTML = '<span class="text-success">Available: ' + stock + ' units</span>';
    } else {
        priceInput.value = '';
        stockAlert.innerHTML = '';
    }
}

function checkStock() {
    const select = document.getElementById('inventorySelect');
    const qtyInput = document.getElementById('quantityInput');
    const stockAlert = document.getElementById('stockAlert');
    
    const selected = select.options[select.selectedIndex];
    if (selected.value) {
        const stock = parseInt(selected.dataset.stock);
        const qty = parseInt(qtyInput.value) || 0;
        
        if (qty > stock) {
            stockAlert.innerHTML = '<span class="text-danger">Only ' + stock + ' available!</span>';
            qtyInput.value = stock;
        } else {
            stockAlert.innerHTML = '<span class="text-success">Available: ' + stock + ' units</span>';
        }
    }
}
</script>

<script>
function printReceipt(id) {
    const w = 450, h = 650;
    const l = (screen.width/2)-(w/2), t = (screen.height/2)-(h/2);
    window.open('print_receipt.php?id='+id, 'Receipt', `width=${w},height=${h},top=${t},left=${l}`);
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>