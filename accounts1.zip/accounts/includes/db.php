<?php
declare(strict_types=1);

if (isset($pdo) && $pdo instanceof PDO) {
    return;
}

$configPaths = [
    dirname(__DIR__, 2) . '/config/database.php',
    dirname(__DIR__, 2) . '/config/db.php',
    dirname(__DIR__) . '/config/database.php',
    dirname(__DIR__) . '/config/db.php',
];

$databaseConfig = null;

foreach ($configPaths as $configPath) {
    if (!is_file($configPath)) {
        continue;
    }

    $loadedConfig = require $configPath;

    if (is_array($loadedConfig)) {
        $databaseConfig = $loadedConfig;
        break;
    }

    if (isset($pdo) && $pdo instanceof PDO) {
        return;
    }
}

if (!is_array($databaseConfig)) {
    error_log('Accounts database config not found. Checked: ' . implode(', ', $configPaths));
    throw new RuntimeException('Database configuration file was not found.');
}

$host = $databaseConfig['host'] ?? 'localhost';
$database = $databaseConfig['database'] ?? '';
$username = $databaseConfig['username'] ?? '';
$password = $databaseConfig['password'] ?? '';
$charset = $databaseConfig['charset'] ?? 'utf8mb4';

try {
    $dsn = "mysql:host={$host};dbname={$database};charset={$charset}";
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET NAMES {$charset} COLLATE utf8mb4_unicode_ci");
} catch (Throwable $e) {
    error_log('Accounts database connection failed: ' . $e->getMessage());
    throw new RuntimeException('Database connection failed.');
}
