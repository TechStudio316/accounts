<?php
// Note: session_start() should only be called once. 
// If your main pages already call it, you can remove it from here, 
// but keeping it with a check is safest.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * 1. ACCESS CONTROL
 */
function checkAccess() {
    if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
        header("Location: login.php");
        exit();
    }
}

/**
 * 2. AUDIT LOGGING (The New Addition)
 */
function logAudit($pdo, $action, $details) {
    if (!isset($_SESSION['user_id'])) return;

    try {
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (user_id, action, details, ip_address, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        
        $user_id = $_SESSION['user_id'];
        $ip = $_SERVER['REMOTE_ADDR'];
        
        $stmt->execute([$user_id, $action, $details, $ip]);
    } catch (PDOException $e) {
        // Log error to PHP error log so it doesn't interrupt the user experience
        error_log("Audit Log Error: " . $e->getMessage());
    }
}

/**
 * 3. FINANCIAL CALCULATIONS
 */
function getOutstandingBalance($pdo, $student_id) {
    // Note: Ensure your table names match (student_bills vs invoices)
    // Based on your previous code, you might be using 'student_bills'
    $stmt = $pdo->prepare("SELECT SUM(balance) FROM student_bills WHERE student_id = ?");
    $stmt->execute([$student_id]);
    return $stmt->fetchColumn() ?: 0;
}
?>