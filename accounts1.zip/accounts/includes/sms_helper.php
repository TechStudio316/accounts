<?php
function sendDebtReminder($phone, $name, $amount) {
    // Basic formatting: ensure phone starts with 234
    if (strpos($phone, '0') === 0) {
        $phone = '234' . substr($phone, 1);
    }

    $message = "Dear Parent, this is a reminder that " . $name . " has an outstanding balance of N" . number_format($amount, 0) . ". Please kindly make payment at the school office. Thank you.";
    
    // Example: Integration with a standard API (Change URL/Params to match your provider)
    /*
    $api_url = "https://api.smsprovider.com/send";
    $params = [
        'api_key' => 'YOUR_KEY',
        'to' => $phone,
        'from' => 'SCHOOL_RMS',
        'message' => $message
    ];
    file_get_contents($api_url . '?' . http_build_query($params));
    */
    
    return true; // Simulate success
}
?>