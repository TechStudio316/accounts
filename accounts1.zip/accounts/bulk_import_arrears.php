<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];
    $handle = fopen($file, "r");
    $rowCount = 0;
    $successCount = 0;
    $errors = [];

    try {
        $pdo->beginTransaction();
        
        // Skip header row if your CSV has one
        fgetcsv($handle); 

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $rowCount++;
            $adm_no = trim($data[0]);
            $amount = (float)$data[1];
            $session_id = (int)$data[2];
            $term_id = (int)$data[3];

            // 1. Find Student ID from Admission No
            $stmt = $pdo->prepare("SELECT id FROM students WHERE admission_no = ?");
            $stmt->execute([$adm_no]);
            $student = $stmt->fetch();

            if ($student) {
                // 2. Create the Arrears Bill
                $ins = $pdo->prepare("INSERT INTO student_bills (student_id, item_name, total_amount, paid_amount, balance, session_id, term_id, status) 
                                       VALUES (?, 'Legacy Arrears Import', ?, 0, ?, ?, ?, 'unpaid')");
                $ins->execute([$student['id'], $amount, $amount, $session_id, $term_id]);
                $successCount++;
            } else {
                $errors[] = "Row $rowCount: Student with Admission No '$adm_no' not found.";
            }
        }

        $pdo->commit();
        $message = "<div class='alert alert-success'>Successfully imported $successCount records!</div>";
        if(!empty($errors)) {
            $message .= "<div class='alert alert-warning small'>".implode('<br>', $errors)."</div>";
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "<div class='alert alert-danger'>Critical Error: " . $e->getMessage() . "</div>";
    }
    fclose($handle);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bulk Debt Import | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: #f1f5f9; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: #0f172a; color: white; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card { border: none; border-radius: 15px; border-left: 5px solid #0d6efd; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <h6 class="fw-bold">SchoolRMS | Bulk Tools</h6>
    </div>
    <nav class="nav flex-column px-3">
        <a class="nav-link text-white-50" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Reports</a>
        <a class="nav-link text-white-50" href="import_arrears.php"><i class="bi bi-person-plus me-2"></i> Single Import</a>
        <a class="nav-link text-white fw-bold" href="bulk_import_arrears.php"><i class="bi bi-file-earmark-spreadsheet me-2"></i> Bulk Import</a>
    </nav>
</div>

<div class="main-content">
    <h3 class="fw-bold">Bulk Arrears Import</h3>
    <p class="text-muted">Upload a CSV file to assign old debts to multiple students at once.</p>

    <?= $message ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card p-4 shadow-sm bg-white">
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Select CSV File</label>
                        <input type="file" name="csv_file" class="form-control" accept=".csv" required>
                        <div class="form-text mt-2">Maximum file size: 2MB.</div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2">
                        <i class="bi bi-cloud-upload me-2"></i> Start Import Process
                    </button>
                </form>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card p-4 shadow-sm bg-light border-0">
                <h6 class="fw-bold"><i class="bi bi-info-circle me-2"></i> CSV Format Guide</h6>
                <p class="small">Your Excel/CSV should look like this:</p>
                <table class="table table-sm table-bordered bg-white small">
                    <thead>
                        <tr>
                            <th>adm_no</th>
                            <th>amount</th>
                            <th>session_id</th>
                            <th>term_id</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td>2023/001</td><td>15000</td><td>1</td><td>3</td></tr>
                        <tr><td>2023/045</td><td>5500</td><td>1</td><td>3</td></tr>
                    </tbody>
                </table>
                <p class="x-small text-danger mb-0">* Ensure admission numbers match exactly as they appear in the system.</p>
            </div>
        </div>
    </div>
</div>

</body>
</html>