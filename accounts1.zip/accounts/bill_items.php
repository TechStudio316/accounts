<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/includes/db.php'; 

$msg = "";

// --- 1. HANDLE DELETE ACTION ---
if (isset($_GET['delete_id'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM fee_items WHERE id = ?");
        $stmt->execute([$_GET['delete_id']]);
        $msg = "<div class='alert alert-success shadow-sm'>Item deleted successfully!</div>";
    } catch (Exception $e) { 
        $msg = "<div class='alert alert-danger shadow-sm'>Error deleting item: " . $e->getMessage() . "</div>"; 
    }
}

// --- 2. HANDLE EDIT/UPDATE ACTION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_item'])) {
    try {
        $stmt = $pdo->prepare("UPDATE fee_items SET item_name = ?, amount = ?, class_id = ?, session_id = ?, term = ? WHERE id = ?");
        $stmt->execute([
            $_POST['item_name'], 
            $_POST['amount'], 
            $_POST['class_id'], 
            $_POST['session_id'], 
            $_POST['term_id'], 
            $_POST['item_id']
        ]);
        $msg = "<div class='alert alert-success shadow-sm'>Item updated successfully!</div>";
    } catch (Exception $e) {
        $msg = "<div class='alert alert-danger shadow-sm'>Update Failed: " . $e->getMessage() . "</div>";
    }
}

// --- 3. HANDLE ADD ACTION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item'])) {
    try {
        $stmt = $pdo->prepare("INSERT INTO fee_items (item_name, amount, class_id, session_id, term) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$_POST['item_name'], $_POST['amount'], $_POST['class_id'], $_POST['session_id'], $_POST['term_id']]);
        $msg = "<div class='alert alert-success shadow-sm'>Fee item added successfully!</div>";
    } catch (Exception $e) { 
        $msg = "<div class='alert alert-danger shadow-sm'>Error: " . $e->getMessage() . "</div>"; 
    }
}

// --- 4. DATA FETCHING ---
$f_class = $_GET['f_class'] ?? '';
$f_session = $_GET['f_session'] ?? '';
$f_term = $_GET['f_term'] ?? '';

try {
    $classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();
    $sessions = $pdo->query("SELECT id, name FROM sessions ORDER BY name DESC")->fetchAll();
    $term_activations = $pdo->query("SELECT term_id FROM term_activations ORDER BY term_id ASC")->fetchAll();
    $term_names = [1 => "First Term", 2 => "Second Term", 3 => "Third Term"];

    $query = "SELECT f.*, c.name as class_name, s.name as session_name 
              FROM fee_items f 
              LEFT JOIN classes c ON f.class_id = c.id 
              LEFT JOIN sessions s ON f.session_id = s.id 
              WHERE 1=1";

    $params = [];
    if ($f_class != '') { $query .= " AND f.class_id = ?"; $params[] = $f_class; }
    if ($f_session != '') { $query .= " AND f.session_id = ?"; $params[] = $f_session; }
    if ($f_term != '') { $query .= " AND f.term = ?"; $params[] = $f_term; }

    $query .= " ORDER BY f.id DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $items = $stmt->fetchAll();
} catch (PDOException $e) { die("Database Error: " . $e->getMessage()); }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill Items | SchoolRMS Accounts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; transition: 0.3s; z-index: 1000; }
        .main-content { margin-left: 260px; padding: 30px; transition: 0.3s; }
        .nav-link { color: #94a3b8; padding: 12px 20px; border-radius: 10px; margin: 4px 15px; text-decoration: none; display: block; }
        .nav-link:hover { background: rgba(255,255,255,0.1); color: white; }
        .nav-link.active { background: var(--primary-blue); color: white; }
        .card { border: none; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
        @media (max-width: 992px) { .sidebar { left: -260px; } .main-content { margin-left: 0; } .sidebar.active { left: 0; } }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <img src="../public/uploads/school_logo.png" alt="Logo" style="height: 60px;">
        <h6 class="mt-3 fw-bold text-white">SchoolRMS | Accounts</h6>
    </div>
    <nav class="nav flex-column">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link active" href="bill_items.php"><i class="bi bi-list-stars me-2"></i> Bill Items</a>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Reports</a>
        <a class="nav-link text-danger mt-5" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Bill Item Settings</h3>
            <p class="text-muted mb-0">Manage individual fee components for student billing.</p>
        </div>
        <div>
            <button class="btn btn-white d-lg-none shadow-sm me-2" onclick="document.getElementById('sidebar').classList.toggle('active')">
                <i class="bi bi-list"></i>
            </button>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
                <i class="bi bi-plus-lg me-2"></i>Add New Fee
            </button>
        </div>
    </div>

    <div class="card p-4 mb-4">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label small fw-bold text-secondary">FILTER CLASS</label>
                <select name="f_class" class="form-select bg-light border-0">
                    <option value="">All Classes</option>
                    <?php foreach($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($f_class == $c['id']) ? 'selected' : '' ?>><?= $c['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold text-secondary">SESSION</label>
                <select name="f_session" class="form-select bg-light border-0">
                    <option value="">All Sessions</option>
                    <?php foreach($sessions as $s): ?>
                        <option value="<?= $s['id'] ?>" <?= ($f_session == $s['id']) ? 'selected' : '' ?>><?= $s['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold text-secondary">TERM</label>
                <select name="f_term" class="form-select bg-light border-0">
                    <option value="">All Terms</option>
                    <?php foreach($term_activations as $t): ?>
                        <option value="<?= $t['term_id'] ?>" <?= ($f_term == $t['term_id']) ? 'selected' : '' ?>>
                            <?= $term_names[$t['term_id']] ?? "Term ".$t['term_id'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-dark w-100">Apply Filters</button>
                <a href="bill_items.php" class="btn btn-outline-secondary px-3"><i class="bi bi-arrow-clockwise"></i></a>
            </div>
        </form>
    </div>

    <?= $msg ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr class="text-secondary small fw-bold">
                            <th class="ps-4">FEE DESCRIPTION</th>
                            <th>CLASS</th>
                            <th>SESSION / TERM</th>
                            <th>AMOUNT</th>
                            <th class="text-center">ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($items)): ?>
                            <tr><td colspan="5" class="text-center py-5 text-muted">No fee items found.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td class="ps-4 fw-medium"><?= htmlspecialchars($item['item_name']) ?></td>
                            <td><span class="badge bg-info bg-opacity-10 text-info"><?= htmlspecialchars($item['class_name'] ?? 'General') ?></span></td>
                            <td class="small text-muted">
                                <?= htmlspecialchars($item['session_name']) ?><br>
                                <span class="text-dark"><?= $term_names[$item['term']] ?? 'N/A' ?></span>
                            </td>
                            <td class="fw-bold text-primary">₦<?= number_format($item['amount'], 2) ?></td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editModal<?= $item['id'] ?>">
                                    <i class="bi bi-pencil-square"></i>
                                </button>
                                <a href="?delete_id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this fee item?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>

                        <div class="modal fade" id="editModal<?= $item['id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <form class="modal-content" method="POST">
                                    <div class="modal-header border-0">
                                        <h5 class="fw-bold">Edit Fee Item</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                                        <div class="mb-3">
                                            <label class="form-label small fw-bold">Item Name</label>
                                            <input type="text" name="item_name" class="form-control" value="<?= htmlspecialchars($item['item_name']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label small fw-bold">Amount (₦)</label>
                                            <input type="number" step="0.01" name="amount" class="form-control" value="<?= $item['amount'] ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label small fw-bold">Class</label>
                                            <select name="class_id" class="form-select">
                                                <?php foreach($classes as $c): ?>
                                                    <option value="<?= $c['id'] ?>" <?= ($c['id'] == $item['class_id']) ? 'selected' : '' ?>><?= $c['name'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label small fw-bold">Session</label>
                                                <select name="session_id" class="form-select">
                                                    <?php foreach($sessions as $s): ?>
                                                        <option value="<?= $s['id'] ?>" <?= ($s['id'] == $item['session_id']) ? 'selected' : '' ?>><?= $s['name'] ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label small fw-bold">Term</label>
                                                <select name="term_id" class="form-select">
                                                    <?php foreach($term_activations as $t): ?>
                                                        <option value="<?= $t['term_id'] ?>" <?= ($t['term_id'] == $item['term']) ? 'selected' : '' ?>>
                                                            <?= $term_names[$t['term_id']] ?? "Term ".$t['term_id'] ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer border-0">
                                        <button type="submit" name="edit_item" class="btn btn-primary w-100 py-2">Update Fee Record</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" method="POST">
            <div class="modal-header border-0">
                <h5 class="fw-bold">Add New Fee Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Item Name</label>
                    <input type="text" name="item_name" class="form-control" placeholder="e.g. Tuition Fee" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Amount (₦)</label>
                    <input type="number" step="0.01" name="amount" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Class</label>
                    <select name="class_id" class="form-select">
                        <?php foreach($classes as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= $c['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Session</label>
                        <select name="session_id" class="form-select">
                            <?php foreach($sessions as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= $s['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Term</label>
                        <select name="term_id" class="form-select">
                            <?php foreach($term_activations as $t): ?>
                                <option value="<?= $t['term_id'] ?>"><?= $term_names[$t['term_id']] ?? "Term ".$t['term_id'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" name="add_item" class="btn btn-primary w-100 py-2">Save Fee Item</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>