<?php
session_start();
// Redirect to dashboard if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | SchoolRMS Accounts</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f4f7f9; 
            height: 100vh; 
            display: flex; 
            align-items: center; 
            margin: 0;
        }
        .login-container { 
            max-width: 400px; 
            width: 100%; 
            margin: auto; 
        }
        .card { 
            border: none; 
            border-radius: 20px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.1); 
            overflow: hidden; 
        }
        .card-header { 
            background: white; 
            border: none; 
            padding-top: 40px; 
        }
        .btn-primary { 
            background: #2563eb; 
            border: none; 
            padding: 12px; 
            border-radius: 10px; 
            font-weight: 600; 
            transition: 0.3s;
        }
        .btn-primary:hover {
            background: #1d4ed8;
            transform: translateY(-1px);
        }
        .form-control { 
            padding: 12px; 
            border-radius: 10px; 
            background: #f8fafc; 
            border: 1px solid #e2e8f0; 
        }
        .form-control:focus {
            background: #fff;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        .alert {
            border-radius: 10px;
            font-size: 0.85rem;
            border: none;
        }
    </style>
</head>
<body>

    <div class="login-container p-3">
        <div class="card">
            <div class="card-header text-center">
                <img src="/storage/logos/school-1.png" alt="School Logo" style="height: 80px; margin-bottom: 15px; object-fit: contain;">
                <h4 class="fw-bold text-dark mb-0">SchoolRMS | Accounts</h4>
                <p class="text-muted small mt-1">Financial Management System</p>
            </div>
            
            <div class="card-body p-4">
                
                <?php if(isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <div>
                            <?php 
                                echo $_SESSION['error']; 
                                unset($_SESSION['error']); 
                            ?>
                        </div>
                    </div>
                <?php endif; ?>

                <form action="auth_process.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label text-secondary small fw-bold">EMAIL ADDRESS</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-muted"></i></span>
                            <input type="email" name="email" class="form-control border-start-0" placeholder="e.g. accountant@bgbschools.com" required>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label text-secondary small fw-bold">PASSWORD</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-muted"></i></span>
                            <input type="password" name="password" class="form-control border-start-0" placeholder="••••••••" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 mb-2">
                        Sign In <i class="bi bi-arrow-right ms-1"></i>
                    </button>
                </form>
            </div>
            
            <div class="card-footer bg-light border-0 py-3 text-center">
                <p class="text-muted small mb-0">&copy; <?php echo date('Y'); ?> SchoolRMS v2.0</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>