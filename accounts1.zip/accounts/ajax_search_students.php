<?php
require_once __DIR__ . '/includes/db.php';
if(isset($_POST['query'])){
    $search = "%" . $_POST['query'] . "%";
    // ADDED id to the SELECT
    $stmt = $pdo->prepare("SELECT id, name, admission_no FROM students WHERE name LIKE ? OR admission_no LIKE ? LIMIT 5");
    $stmt->execute([$search, $search]);
    $results = $stmt->fetchAll();

    foreach($results as $row){
        // ADDED data-id attribute here
        echo '<div class="list-group-item list-group-item-action suggestion-item" 
                   data-id="'.$row['id'].'" 
                   data-name="'.$row['name'].'">';
        echo '<strong>'.$row['name'].'</strong> <small class="text-muted">('.$row['admission_no'].')</small>';
        echo '</div>';
    }
}
?>