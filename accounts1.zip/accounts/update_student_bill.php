<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

$student_id = $_GET['student_id'] ?? null;
$session_id = $_GET['session'] ?? null;
$term_id = $_GET['term'] ?? null;
$ip_address = $_SERVER['REMOTE_ADDR'];

if (!$student_id || !$session_id || !$term_id) {
    header("Location: billing.php");
    exit();
}

$message = "";

// --- 0. PRE-FETCH STUDENT NAME FOR DESCRIPTIVE AUDIT LOGS ---
try {
    $stmt_name = $pdo->prepare("SELECT name, admission_no, class_id FROM students WHERE id = ?");
    $stmt_name->execute([$student_id]);
    $student = $stmt_name->fetch();
    $student_display_name = $student ? $student['name'] : "Unknown Student (ID: $student_id)";
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

// --- 1. HANDLE DELETE ITEM ---
if (isset($_GET['delete_item'])) {
    $item_id = $_GET['delete_item'];
    try {
        // Fetch item details for audit before deletion
        $stmt_item = $pdo->prepare("SELECT item_name, total_amount FROM student_bills WHERE id = ?");
        $stmt_item->execute([$item_id]);
        $old_data = $stmt_item->fetch();

        if ($old_data) {
            $stmt = $pdo->prepare("DELETE FROM student_bills WHERE id = ? AND student_id = ?");
            $stmt->execute([$item_id, $student_id]);

            // LOG AUDIT WITH STUDENT NAME
            $audit = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
            $audit_detail = "Removed '{$old_data['item_name']}' (₦" . number_format($old_data['total_amount'], 2) . ") from $student_display_name";
            $audit->execute([$_SESSION['user_id'], 'DELETE_BILL_ITEM', $audit_detail, $ip_address]);

            $message = "<div class='alert alert-success border-0 shadow-sm'>Item removed successfully.</div>";
        }
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger border-0 shadow-sm'>Error deleting item.</div>";
    }
}

// --- 2. HANDLE UPDATE ITEM AMOUNTS (EDITS) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_bill_amounts'])) {
    try {
        $pdo->beginTransaction();
        foreach ($_POST['amounts'] as $id => $new_amount) {
            $stmt = $pdo->prepare("SELECT item_name, total_amount, amount_paid FROM student_bills WHERE id = ?");
            $stmt->execute([$id]);
            $old = $stmt->fetch();
            
            if($old && $old['total_amount'] != $new_amount) {
                $new_balance = $new_amount - ($old['amount_paid'] ?: 0);
                $upd = $pdo->prepare("UPDATE student_bills SET total_amount = ?, balance = ? WHERE id = ? AND student_id = ?");
                $upd->execute([$new_amount, $new_balance, $id, $student_id]);

                // LOG AUDIT WITH STUDENT NAME
                $audit = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
                $audit_detail = "Changed '{$old['item_name']}' from ₦" . number_format($old['total_amount'], 2) . " to ₦" . number_format($new_amount, 2) . " for $student_display_name";
                $audit->execute([$_SESSION['user_id'], 'UPDATE_BILL_AMOUNT', $audit_detail, $ip_address]);
            }
        }
        $pdo->commit();
        $message = "<div class='alert alert-success border-0 shadow-sm'>Bill updated successfully.</div>";
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $message = "<div class='alert alert-danger'>Error saving edits: " . $e->getMessage() . "</div>";
    }
}

// --- 3. HANDLE ADD NEW ITEM ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bill_item'])) {
    $item_data = explode('|', $_POST['selected_item']);
    $item_name = $item_data[0];
    $amount = $item_data[1];

    try {
        $check = $pdo->prepare("SELECT id FROM student_bills WHERE student_id = ? AND item_name = ? AND session_id = ? AND term_id = ?");
        $check->execute([$student_id, $item_name, $session_id, $term_id]);
        
        if ($check->fetch()) {
            $message = "<div class='alert alert-warning border-0 shadow-sm'><strong>Duplicate Item:</strong> '$item_name' already exists.</div>";
        } else {
            $ins = $pdo->prepare("INSERT INTO student_bills (student_id, item_name, total_amount, balance, session_id, term_id) VALUES (?, ?, ?, ?, ?, ?)");
            $ins->execute([$student_id, $item_name, $amount, $amount, $session_id, $term_id]);
            
            // LOG AUDIT WITH STUDENT NAME
            $audit = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
            $audit_detail = "Added '{$item_name}' (₦" . number_format($amount, 2) . ") to $student_display_name";
            $audit->execute([$_SESSION['user_id'], 'ADD_BILL_ITEM', $audit_detail, $ip_address]);
            
            $message = "<div class='alert alert-success border-0 shadow-sm'>Item added.</div>";
        }
    } catch (PDOException $e) { 
        $message = "<div class='alert alert-danger'>Error updating bill.</div>"; 
    }
}

// --- 4. FETCH REMAINING UI DATA ---
try {
    // Total Account Balance across the whole ledger
    $stmt_total_bal = $pdo->prepare("SELECT SUM(balance) FROM student_bills WHERE student_id = ?");
    $stmt_total_bal->execute([$student_id]);
    $raw_ledger_balance = $stmt_total_bal->fetchColumn() ?: 0;
    $advanced_credit = ($raw_ledger_balance < 0) ? abs($raw_ledger_balance) : 0;

    // Current View Bills
    $stmt_items = $pdo->prepare("SELECT * FROM student_bills WHERE student_id = ? AND session_id = ? AND term_id = ?");
    $stmt_items->execute([$student_id, $session_id, $term_id]);
    $bill_items = $stmt_items->fetchAll();
    
    // Term's Outstanding specifically
    $stmt_out = $pdo->prepare("SELECT SUM(balance) FROM student_bills WHERE student_id = ? AND session_id = ? AND term_id = ? AND balance > 0");
    $stmt_out->execute([$student_id, $session_id, $term_id]);
    $term_outstanding = $stmt_out->fetchColumn() ?: 0;

    // Available class fees
    $stmt_class_fees = $pdo->prepare("SELECT item_name, amount FROM fee_items WHERE class_id = ? AND session_id = ? AND term = ?");
    $stmt_class_fees->execute([$student['class_id'], $session_id, $term_id]);
    $available_fees = $stmt_class_fees->fetchAll();

    $total_bill_sum = 0;
    foreach($bill_items as $bi) { $total_bill_sum += $bi['total_amount']; }
} catch (PDOException $e) { die("Database Error"); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Bill | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-width: 260px; --primary-color: #4361ee; --dark-blue: #0f172a; }
        body { background-color: #f1f5f9; font-family: 'Inter', sans-serif; }
        .sidebar { width: var(--sidebar-width); height: 100vh; position: fixed; left: 0; top: 0; background: var(--dark-blue); color: #fff; z-index: 1000; }
        .sidebar-header { padding: 25px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .nav-link { color: #94a3b8; padding: 12px 25px; display: flex; align-items: center; text-decoration: none; transition: 0.3s; border-left: 4px solid transparent; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: #fff; }
        .nav-link.active { background: rgba(67, 97, 238, 0.15); color: #4361ee; border-left-color: #4361ee; }
        .main-content { margin-left: var(--sidebar-width); padding: 30px; transition: 0.3s; }
        .card { border: none; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .editable-amount { max-width: 150px; text-align: right; font-weight: bold; border: 1px dashed #ccc; }
        .balance-chip { min-width: 140px; }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h4 class="fw-bold mb-0">School<span class="text-primary">RMS</span></h4>
        <small class="text-muted text-uppercase fw-bold" style="font-size: 0.65rem;">Accounts Department</small>
    </div>
    <div class="py-4">
        <a href="dashboard.php" class="nav-link"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>
        <a href="billing.php" class="nav-link active"><i class="bi bi-receipt-cutoff"></i> Fee Management</a>
        <a href="bill_items.php" class="nav-link"><i class="bi bi-list-check"></i> Bill Items</a>
        <a href="payments.php" class="nav-link"><i class="bi bi-credit-card-2-front"></i> Payments</a>
        <div class="mt-5 px-4"><a href="logout.php" class="btn btn-danger w-100 rounded-pill py-2">Logout</a></div>
    </div>
</div>

<div class="main-content">
    <div class="mb-4 d-flex justify-content-between align-items-start">
        <div>
            <a href="view_class_bills.php?class_id=<?= $student['class_id'] ?>&session=<?= $session_id ?>&term=<?= $term_id ?>" class="text-decoration-none small fw-bold text-primary">
                <i class="bi bi-arrow-left me-1"></i> Back to Class List
            </a>
            <h3 class="fw-bold mt-2 mb-0"><?= htmlspecialchars($student['name'] ?? 'Loading...') ?></h3>
            <p class="text-muted small mb-0">ADM: <?= htmlspecialchars($student['admission_no'] ?? 'N/A') ?></p>
        </div>
        
        <div class="d-flex gap-3">
            <div class="bg-white px-3 py-2 rounded shadow-sm border-start border-danger border-4 balance-chip">
                <small class="text-muted fw-bold d-block" style="font-size: 0.7rem;">TERM OUTSTANDING</small>
                <span class="fw-bold text-danger">₦<?= number_format($term_outstanding, 2) ?></span>
            </div>
            <div class="bg-white px-3 py-2 rounded shadow-sm border-start border-success border-4 balance-chip">
                <small class="text-muted fw-bold d-block" style="font-size: 0.7rem;">TOTAL ADVANCED CREDIT</small>
                <span class="fw-bold text-success">₦<?= number_format($advanced_credit, 2) ?></span>
            </div>
            <a href="generate_invoice.php?student_id=<?= $student_id ?>&session=<?= $session_id ?>&term=<?= $term_id ?>" target="_blank" class="btn btn-dark shadow-sm d-flex align-items-center">
                <i class="bi bi-printer-fill me-2"></i> Print Invoice
            </a>
        </div>
    </div>

    <?= $message ?>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h6 class="fw-bold mb-0">Invoice Breakdown</h6>
                    <small class="text-muted"><i class="bi bi-info-circle me-1"></i> Changes here update the total bill and current balance.</small>
                </div>
                
                <form method="POST">
                    <table class="table align-middle">
                        <thead class="bg-light small text-muted">
                            <tr><th>ITEM</th><th class="text-end">AMOUNT (₦)</th><th class="text-end">ACTION</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach($bill_items as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['item_name']) ?></td>
                                <td class="text-end">
                                    <input type="number" step="0.01" name="amounts[<?= $item['id'] ?>]" 
                                           class="form-control form-control-sm d-inline-block editable-amount" 
                                           value="<?= $item['total_amount'] ?>">
                                </td>
                                <td class="text-end">
                                    <a href="?student_id=<?= $student_id ?>&session=<?= $session_id ?>&term=<?= $term_id ?>&delete_item=<?= $item['id'] ?>" class="btn btn-sm text-danger" onclick="return confirm('Remove this item?')"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-dark">
                                <td>TOTAL TERM BILL</td>
                                <td class="text-end fw-bold">₦<?= number_format($total_bill_sum, 2) ?></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                    
                    <div class="text-end mt-3">
                        <button type="submit" name="update_bill_amounts" class="btn btn-primary px-4 shadow-sm">
                            <i class="bi bi-save me-2"></i> Save Bill Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card p-4 border-primary border-top border-4">
                <h6 class="fw-bold mb-3">Add Class Fee Item</h6>
                <form method="POST">
                    <select name="selected_item" class="form-select bg-light border-0 mb-3" required>
                        <option value="">-- Select --</option>
                        <?php foreach($available_fees as $fee): ?>
                            <option value="<?= htmlspecialchars($fee['item_name']) ?>|<?= $fee['amount'] ?>"><?= $fee['item_name'] ?> (₦<?= number_format($fee['amount'], 2) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="add_bill_item" class="btn btn-outline-primary w-100 py-2">Add Item</button>
                </form>
            </div>
            
            <div class="card p-4 mt-4 bg-light border-0">
                <h6 class="fw-bold mb-2">Accounting Note</h6>
                <ul class="small text-muted ps-3">
                    <li><b>Advanced Credit</b> is funds currently held in the student's ledger (total balance < 0).</li>
                    <li><b>Term Outstanding</b> is the specific debt for the selected session and term.</li>
                    <li>Updating an item's amount will automatically recalculate its balance based on previous payments.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
</body>
</html>