<?php
/**
 * LOGIN PROCESSOR
 * Ensure there is NO whitespace or HTML before this <?php tag.
 */
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit();
}

try {
    require_once __DIR__ . '/includes/db.php';
} catch (Throwable $e) {
    error_log("Auth bootstrap error: " . $e->getMessage());
    $_SESSION['error'] = "Database connection failed. Please contact the administrator.";
    header("Location: login.php");
    exit();
}

$email = trim(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));
$password = trim($_POST['password'] ?? '');

try {
    $stmt = $pdo->prepare("
        SELECT id, full_name, email, role, password_hash, last_active, is_active
        FROM users
        WHERE email = ?
        LIMIT 1
    ");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    $is_correct = false;

    // 1. Check if user exists
    if ($user && (int)($user['is_active'] ?? 1) === 1) {
        // 2. Verify Password (Standard Hash Check)
        if (password_verify($password, $user['password_hash'])) {
            $is_correct = true;
        }
        // 3. Fallback: Plain-text check, then upgrade to a secure hash
        elseif ($password === $user['password_hash']) {
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $update = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $update->execute([$newHash, $user['id']]);
            $is_correct = true;
        }
    }

    // 4. Final check for Role and successful authentication
    if ($is_correct && in_array($user['role'], ['admin', 'accountant'], true)) {
        // Set Session Data
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name']    = $user['full_name'];
        $_SESSION['role']    = $user['role'];
        $_SESSION['email']   = $user['email'];

        // Update Activity Log
        $update_stmt = $pdo->prepare("UPDATE users SET last_active = NOW() WHERE id = ?");
        $update_stmt->execute([$user['id']]);

        // Redirect to Dashboard
        header("Location: dashboard.php");
        exit();
    }

    // Handle Failed Login (Wrong password, wrong role, or non-existent user)
    $_SESSION['error'] = "Access denied. Check credentials or permissions.";
    header("Location: login.php");
    exit();
} catch (Throwable $e) {
    // Internal logging
    error_log("Auth Error: " . $e->getMessage());
    $_SESSION['error'] = "A system error occurred. Please try again later.";
    header("Location: login.php");
    exit();
}
