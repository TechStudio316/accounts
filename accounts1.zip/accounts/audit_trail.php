<?php
session_start();

/**
 * ACCESS CONTROL: 
 * Only 'admin' is allowed.
 */
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: dashboard.php?error=unauthorized");
    exit();
}

require_once __DIR__ . '/includes/db.php';

try {
    // 1. Fetch School Info for Branding
    $school = $pdo->query("SELECT name FROM school_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $school_name = $school['name'] ?? 'SchoolRMS';
    $school_logo = "/public/uploads/school_logo.png";

    // 2. Fetch Logs with User Information
    $query = "SELECT al.*, u.full_name as display_name, u.role 
              FROM audit_logs al 
              LEFT JOIN users u ON al.user_id = u.id 
              ORDER BY al.created_at DESC 
              LIMIT 200"; 
    
    $stmt = $pdo->query($query);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Trail | <?= htmlspecialchars($school_name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; transition: 0.3s; z-index: 1000; overflow-y: auto; }
        .main-content { margin-left: 260px; padding: 30px; transition: 0.3s; }
        .nav-link { color: #94a3b8; padding: 10px 20px; border-radius: 8px; margin: 2px 15px; text-decoration: none; display: block; font-size: 0.9rem; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: white; }
        .nav-link.active { background: var(--primary-blue); color: white; }
        .menu-label { font-size: 0.7rem; font-weight: 700; color: #475569; margin: 15px 25px 5px; text-transform: uppercase; letter-spacing: 1px; }
        
        .log-card { border: none; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); background: white; overflow: hidden; }
        .badge-user { background: #f1f5f9; color: #475569; font-weight: 600; border: 1px solid #e2e8f0; }
        
        /* Search Bar Styling */
        .search-container { position: relative; max-width: 400px; }
        .search-container .bi-search { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #94a3b8; }
        .search-input { padding-left: 45px; border-radius: 10px; border: 1px solid #e2e8f0; height: 45px; }
        .search-input:focus { border-color: var(--primary-blue); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }

        /* Action-specific colors */
        .badge-login { background: #dcfce7; color: #166534; }
        .badge-payment { background: #e0f2fe; color: #075985; }
        .badge-delete { background: #fee2e2; color: #991b1b; }
        
        @media (max-width: 992px) { 
            .sidebar { left: -260px; } 
            .main-content { margin-left: 0; padding: 15px; } 
            .sidebar.active { left: 0; } 
        }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <img src="<?= $school_logo ?>" alt="Logo" style="height: 60px; width: 60px; object-fit: contain;">
        <h6 class="mt-3 fw-bold text-truncate text-white"><?= htmlspecialchars($school_name) ?></h6>
    </div>
    <nav class="nav flex-column mb-5">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <div class="menu-label">Finance & Bursary</div>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Record Payment</a>
        <a class="nav-link" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link" href="bill_items.php"><i class="bi bi-list-stars me-2"></i> Bill Items</a>
        <a class="nav-link" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>
        <div class="menu-label">Reports & Audit</div>
        <a class="nav-link" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Financial Analysis</a>
        <a class="nav-link active" href="audit_trail.php"><i class="bi bi-shield-check me-2"></i> Audit Trail</a>
        <div class="menu-label">Administration</div>
        <a class="nav-link" href="school_settings.php"><i class="bi bi-gear me-2"></i> School Settings</a>
        <a class="nav-link text-danger mt-4" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1">System Audit Trail</h3>
            <p class="text-muted mb-0"><i class="bi bi-lock-fill text-warning me-1"></i> Admin Only Activity Monitor</p>
        </div>
        
        <div class="search-container w-100">
            <i class="bi bi-search"></i>
            <input type="text" id="logSearch" class="form-control search-input shadow-sm" placeholder="Search by user, action, date or details...">
        </div>

        <button class="btn btn-outline-primary btn-sm d-lg-none" onclick="document.getElementById('sidebar').classList.toggle('active')">
            <i class="bi bi-list"></i> Menu
        </button>
    </div>

    <div class="card log-card">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" id="auditTable">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4" style="width: 180px;">Date & Time</th>
                        <th style="width: 200px;">User</th>
                        <th style="width: 150px;">Action Type</th>
                        <th>Activity Details</th>
                        <th class="text-end pe-4">IP Address</th>
                    </tr>
                </thead>
                <tbody id="logBody">
                    <?php if (empty($logs)): ?>
                        <tr id="noResults">
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="bi bi-info-circle h2 d-block"></i>
                                No activity logs found yet.
                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php foreach ($logs as $log): 
                        $actionClass = 'bg-primary bg-opacity-10 text-primary';
                        if (stripos($log['action'], 'login') !== false) $actionClass = 'badge-login';
                        if (stripos($log['action'], 'payment') !== false || stripos($log['action'], 'bill') !== false) $actionClass = 'badge-payment';
                        if (stripos($log['action'], 'delete') !== false) $actionClass = 'badge-delete';
                    ?>
                    <tr>
                        <td class="ps-4">
                            <div class="fw-bold text-dark" style="font-size: 0.85rem;"><?= date('M d, Y', strtotime($log['created_at'])) ?></div>
                            <div class="text-muted small"><?= date('h:i:s A', strtotime($log['created_at'])) ?></div>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="badge badge-user rounded-pill px-3 py-2">
                                    <i class="bi bi-person-circle me-1"></i>
                                    <?= htmlspecialchars($log['display_name'] ?? 'System User') ?>
                                </div>
                            </div>
                            <small class="text-muted ms-1"><?= ucfirst($log['role'] ?? 'Unknown') ?></small>
                        </td>
                        <td>
                            <span class="badge rounded-pill fw-bold <?= $actionClass ?>"><?= htmlspecialchars($log['action']) ?></span>
                        </td>
                        <td>
                            <div class="text-dark small" style="max-width: 450px; line-height: 1.4;">
                                <?= htmlspecialchars($log['details']) ?>
                            </div>
                        </td>
                        <td class="text-end pe-4">
                            <span class="badge bg-light text-muted font-monospace" style="font-size: 0.75rem;"><?= $log['ip_address'] ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <tr id="searchNoResults" style="display:none;">
                        <td colspan="5" class="text-center py-5 text-muted">
                            <i class="bi bi-search h2 d-block"></i>
                            No logs match your search criteria.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="card-footer bg-white py-3 text-center">
            <small class="text-muted" id="logCount">Showing last <?= count($logs) ?> security events.</small>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
/**
 * Real-time Table Filter Logic
 */
document.getElementById('logSearch').addEventListener('keyup', function() {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#logBody tr:not(#searchNoResults):not(#noResults)');
    let visibleCount = 0;

    rows.forEach(row => {
        // We get the combined text content of the row to search across all columns
        const text = row.textContent.toLowerCase();
        if (text.includes(filter)) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });

    // Handle "No Results" message
    const noResultsRow = document.getElementById('searchNoResults');
    if (visibleCount === 0 && filter !== '') {
        noResultsRow.style.display = '';
    } else {
        noResultsRow.style.display = 'none';
    }

    // Update the counter text
    document.getElementById('logCount').textContent = filter === '' 
        ? 'Showing last <?= count($logs) ?> security events.' 
        : `Found ${visibleCount} matching logs.`;
});
</script>

</body>
</html>
