<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
    header("Location: login.php");
    exit();
}
require_once '../config/db.php';

$message = "";
$error = "";

// Get current session
try {
    $current_session = $pdo->query("SELECT id, name FROM academic_sessions WHERE is_active = 1 LIMIT 1")->fetch();
    if (!$current_session) {
        $current_session = $pdo->query("SELECT id, name FROM academic_sessions ORDER BY id DESC LIMIT 1")->fetch();
    }
} catch (Exception $e) {
    $current_session = null;
}

// Handle Promotion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['promote_students'])) {
    $source_class_id = (int)$_POST['source_class_id'];
    $destination_class_id = (int)$_POST['destination_class_id'];
    $student_ids = $_POST['student_ids'] ?? [];
    $verdicts = $_POST['verdicts'] ?? [];
    
    if (empty($student_ids)) {
        $error = "Please select at least one student to promote.";
    } elseif ($source_class_id === $destination_class_id) {
        $error = "Source and destination class cannot be the same.";
    } else {
        try {
            $pdo->beginTransaction();
            
            // Get destination class name
            $dest_class = $pdo->prepare("SELECT name, section FROM classes WHERE id = ?");
            $dest_class->execute([$destination_class_id]);
            $dest_class_data = $dest_class->fetch();
            
            foreach ($student_ids as $student_id) {
                $student_id = (int)$student_id;
                $verdict = $verdicts[$student_id] ?? 'Promoted';
                
                // Get current student info
                $student = $pdo->prepare("SELECT full_name, current_class_id FROM students WHERE id = ?");
                $student->execute([$student_id]);
                $student_data = $student->fetch();
                
                // 1. Record in class history (for previous class)
                $history = $pdo->prepare("INSERT INTO student_class_history (school_id, student_id, session_id, class_id, class_name, verdict) VALUES (?, ?, ?, ?, ?, ?)");
                $history->execute([
                    1, // school_id
                    $student_id,
                    $current_session['id'] ?? 1,
                    $source_class_id,
                    $student_data['current_class_name'] ?? 'Unknown',
                    $verdict
                ]);
                
                // 2. Update student's current class
                $update = $pdo->prepare("UPDATE students SET current_class_id = ?, current_class_name = ? WHERE id = ?");
                $update->execute([
                    $destination_class_id,
                    $dest_class_data['name'] ?? 'Unknown',
                    $student_id
                ]);
            }
            
            $pdo->commit();
            $count = count($student_ids);
            $message = "<div class='alert alert-success'><i class='bi bi-check-circle-fill me-2'></i> Successfully promoted $count student(s) to " . htmlspecialchars($dest_class_data['name']) . "!</div>";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Get classes
try {
    $classes = $pdo->query("SELECT id, name, section FROM classes ORDER BY name ASC")->fetchAll();
} catch (Exception $e) {
    $classes = [];
}

// Get students for selected source class
$source_class_id = $_GET['source_class_id'] ?? '';
$students_in_class = [];
if ($source_class_id) {
    try {
        $stmt = $pdo->prepare("SELECT id, admission_no, full_name, current_class_name FROM students WHERE current_class_id = ? AND status = 'active' ORDER BY full_name ASC");
        $stmt->execute([$source_class_id]);
        $students_in_class = $stmt->fetchAll();
    } catch (Exception $e) {
        $students_in_class = [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Promotion | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; z-index: 1000; overflow-y: auto; }
        .main-content { margin-left: 260px; padding: 30px; }
        .nav-link { color: #94a3b8; padding: 10px 20px; border-radius: 8px; margin: 2px 15px; text-decoration: none; display: block; font-size: 0.9rem; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: white; }
        .nav-link.active { background: var(--primary-blue); color: white; }
        .menu-label { font-size: 0.7rem; font-weight: 700; color: #475569; margin: 15px 25px 5px; text-transform: uppercase; }
        .card { border: none; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .checkbox-col { width: 40px; }
        @media (max-width: 992px) { .sidebar { left: -260px; } .main-content { margin-left: 0; } .sidebar.active { left: 0; } }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <h5 class="text-white mb-0">School<span class="text-primary">RMS</span></h5>
        <small class="text-muted">Admin Panel</small>
    </div>
    <nav class="nav flex-column mb-5">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        
        <div class="menu-label">Student Management</div>
        <a class="nav-link" href="students.php"><i class="bi bi-people me-2"></i> Students</a>
        <a class="nav-link active" href="promotion.php"><i class="bi bi-arrow-up-circle me-2"></i> Promotion</a>
        
        <div class="menu-label">Finance & Store</div>
        <a class="nav-link" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link" href="sales.php"><i class="bi bi-cart-check me-2"></i> Sales</a>
        <a class="nav-link" href="inventory.php"><i class="bi bi-box-seam me-2"></i> Inventory</a>
        
        <div class="menu-label">Administration</div>
        <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <?php if ($message): echo $message; endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?></div><?php endif; ?>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1"><i class="bi bi-arrow-up-circle me-2"></i>Student Promotion</h3>
            <p class="text-muted mb-0 small">Promote students to higher classes. Previous records are preserved.</p>
        </div>
    </div>

    <!-- Info Card -->
    <div class="alert alert-info mb-4">
        <i class="bi bi-info-circle me-2"></i>
        <strong>How it works:</strong> Select source class, choose destination class, select students, and click Promote. 
        Student's report cards for previous classes remain intact and can be generated from the report cards page by selecting the appropriate session and class.
    </div>

    <!-- Search/Filter Form -->
    <div class="card p-4 mb-4">
        <form method="GET" class="row g-3">
            <div class="col-md-6">
                <label class="form-label fw-bold">Current Class (Source)</label>
                <select name="source_class_id" class="form-select" required onchange="this.form.submit()">
                    <option value="">-- Select Current Class --</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?= $class['id'] ?>" <?= $source_class_id == $class['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($class['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold">Current Session</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($current_session['name'] ?? 'N/A') ?>" readonly>
                <small class="text-muted">Promotion records will be saved for this session</small>
            </div>
        </form>
    </div>

    <?php if ($source_class_id && !empty($students_in_class)): ?>
    <!-- Promotion Form -->
    <form method="POST">
        <div class="card mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold">
                    <i class="bi bi-people me-2"></i>
                    Students in <?= htmlspecialchars($students_in_class[0]['current_class_name'] ?? 'Selected Class') ?>
                    <span class="badge bg-primary ms-2"><?= count($students_in_class) ?></span>
                </h6>
                <div>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="toggleSelectAll()">
                        <i class="bi bi-check-all me-1"></i> Select All
                    </button>
                </div>
            </div>
            
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="checkbox-col">
                                    <input type="checkbox" id="selectAllCheckbox" onchange="toggleAll(this)">
                                </th>
                                <th>Admission No.</th>
                                <th>Student Name</th>
                                <th>Promotion Status / Verdict</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students_in_class as $student): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="student_ids[]" value="<?= $student['id'] ?>" class="student-checkbox">
                                </td>
                                <td><?= htmlspecialchars($student['admission_no']) ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($student['full_name']) ?></td>
                                <td>
                                    <select name="verdicts[<?= $student['id'] ?>]" class="form-select form-select-sm" style="width: auto;">
                                        <option value="Promoted">Promoted</option>
                                        <option value="Promoted on Trial">Promoted on Trial</option>
                                        <option value="Repeat">Repeat</option>
                                        <option value="Left">Left</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Destination Class Selection -->
        <div class="card p-4 mb-4">
            <h6 class="fw-bold mb-3"><i class="bi bi-arrow-right-circle me-2"></i>Destination Class</h6>
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label fw-bold">Promote To Class</label>
                    <select name="destination_class_id" class="form-select" required>
                        <option value="">-- Select Destination Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <?php if ($class['id'] != $source_class_id): ?>
                                <option value="<?= $class['id'] ?>"><?= htmlspecialchars($class['name']) ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 d-flex align-items-end">
                    <button type="submit" name="promote_students" class="btn btn-success w-100 py-2 fw-bold">
                        <i class="bi bi-check-circle me-2"></i> Promote Selected Students
                    </button>
                </div>
            </div>
        </div>
    </form>

    <!-- Class History Link -->
    <div class="card p-4">
        <h6 class="fw-bold mb-3"><i class="bi bi-clock-history me-2"></i>View Promotion History</h6>
        <p class="text-muted small mb-3">You can view which class each student was in for previous sessions by accessing the student class history.</p>
        <a href="students.php" class="btn btn-outline-secondary">
            <i class="bi bi-people me-2"></i> Manage Students
        </a>
    </div>
    <?php elseif ($source_class_id): ?>
    <div class="alert alert-warning">
        <i class="bi bi-exclamation-triangle me-2"></i>
        No active students found in the selected class.
    </div>
    <?php endif; ?>
</div>

<script>
function toggleAll(source) {
    const checkboxes = document.querySelectorAll('.student-checkbox');
    checkboxes.forEach(cb => cb.checked = source.checked);
    updateSelectedCount();
}

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAllCheckbox');
    selectAll.checked = !selectAll.checked;
    toggleAll(selectAll);
}

function updateSelectedCount() {
    const checked = document.querySelectorAll('.student-checkbox:checked').length;
    const badge = document.getElementById('selectedCount');
    if (badge) badge.textContent = checked;
}

// Add event listeners
document.querySelectorAll('.student-checkbox').forEach(cb => {
    cb.addEventListener('change', updateSelectedCount);
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
