<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

$message = "";

// --- HANDLE IMPORT ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_debt'])) {
    $student_id = $_POST['student_id'];
    $amount = $_POST['amount'];
    $session_id = $_POST['session_id'];
    $term_id = $_POST['term_id'];
    $note = $_POST['note'] ?? 'Previous Debt Import';

    try {
        $stmt = $pdo->prepare("INSERT INTO student_bills (student_id, item_name, total_amount, paid_amount, balance, session_id, term_id, status) 
                               VALUES (?, 'Previous Balance / Arrears', ?, 0, ?, ?, ?, 'unpaid')");
        $stmt->execute([$student_id, $amount, $amount, $session_id, $term_id]);
        
        $message = "<div class='alert alert-success'>Arrears of ₦" . number_format($amount, 2) . " imported successfully!</div>";
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

$sessions = $pdo->query("SELECT * FROM sessions ORDER BY name DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Import Arrears | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: #f1f5f9; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: #0f172a; color: white; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card { border: none; border-radius: 15px; }
        #suggestions { position: absolute; width: 100%; z-index: 1000; top: 100%; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <h6 class="fw-bold">SchoolRMS | Accounts</h6>
    </div>
    <nav class="nav flex-column px-3">
        <a class="nav-link text-white-50" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link text-white-50" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link text-white fw-bold" href="import_arrears.php"><i class="bi bi-box-arrow-in-down me-2"></i> Import Arrears</a>
        <a class="nav-link text-white-50" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Reports</a>
    </nav>
</div>

<div class="main-content">
    <h3 class="fw-bold mb-4">Manual Debt Import (Legacy Records)</h3>
    <p class="text-muted">Use this to bring in outstanding balances from before this system was installed.</p>

    <?= $message ?>

    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="row">
                <div class="col-md-12 mb-4 position-relative">
                    <label class="form-label fw-bold">1. Search Student</label>
                    <input type="text" id="studentSearch" class="form-control py-2" placeholder="Start typing name or admission number..." autocomplete="off" required>
                    <input type="hidden" name="student_id" id="student_id_hidden">
                    <div id="suggestions" class="list-group shadow-sm"></div>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">2. Amount Owed (₦)</label>
                    <input type="number" step="0.01" name="amount" class="form-control" placeholder="0.00" required>
                </div>

                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">3. Origin Session</label>
                    <select name="session_id" class="form-select" required>
                        <?php foreach($sessions as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= $s['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">4. Origin Term</label>
                    <select name="term_id" class="form-select" required>
                        <option value="1">First Term</option>
                        <option value="2">Second Term</option>
                        <option value="3">Third Term</option>
                    </select>
                </div>
            </div>

            <button type="submit" name="import_debt" class="btn btn-primary px-4 mt-3">Import Arrears to Account</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#studentSearch').on('input', function() {
        let query = $(this).val();
        if (query.length > 2) {
            $.ajax({
                url: 'ajax_search_students.php',
                method: 'POST',
                data: { query: query },
                success: function(data) {
                    $('#suggestions').html(data);
                }
            });
        } else {
            $('#suggestions').empty();
        }
    });

    $(document).on('click', '.suggestion-item', function() {
        // We need the student ID from the ajax result
        // Update your ajax_search_students.php to include data-id attribute
        let name = $(this).data('name');
        let id = $(this).data('id'); 
        
        $('#studentSearch').val(name);
        $('#student_id_hidden').val(id);
        $('#suggestions').empty();
    });
});
</script>
</body>
</html>