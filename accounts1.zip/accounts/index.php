<?php
session_start();
// If logged in, go to dashboard. If not, go to login form.
if(isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
} else {
    header("Location: login.php");
}
exit();