<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

// Get parameters from URL
$class_id = $_GET['class_id'] ?? null;
$session_id = $_GET['session'] ?? null;
$term_id = $_GET['term'] ?? null;

if (!$class_id || !$session_id || !$term_id) {
    header("Location: billing.php");
    exit();
}

$term_names = [1 => "First Term", 2 => "Second Term", 3 => "Third Term"];

try {
    // 1. Fetch Class and Session Details for Header
    $stmt_info = $pdo->prepare("
        SELECT c.name as class_name, s.name as session_name 
        FROM classes c, sessions s 
        WHERE c.id = ? AND s.id = ?
    ");
    $stmt_info->execute([$class_id, $session_id]);
    $info = $stmt_info->fetch();

    // 2. Fetch Students and their Total Bill for this specific batch
    $stmt_bills = $pdo->prepare("
        SELECT st.id as student_id, st.name as student_name, st.admission_no,
               SUM(sb.total_amount) as total_bill,
               SUM(sb.balance) as total_balance
        FROM students st
        JOIN student_bills sb ON st.id = sb.student_id
        WHERE st.class_id = ? 
        AND sb.session_id = ? 
        AND sb.term_id = ?
        GROUP BY st.id
        ORDER BY st.name ASC
    ");
    $stmt_bills->execute([$class_id, $session_id, $term_id]);
    $student_bills = $stmt_bills->fetchAll();

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Bills | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-width: 260px; --primary-color: #4361ee; --dark-blue: #0f172a; }
        body { background-color: #f1f5f9; font-family: 'Inter', sans-serif; }
        
        .sidebar { width: var(--sidebar-width); height: 100vh; position: fixed; left: 0; top: 0; background: var(--dark-blue); color: #fff; z-index: 1000; }
        .sidebar-header { padding: 25px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .nav-link { color: #94a3b8; padding: 12px 25px; display: flex; align-items: center; border-left: 4px solid transparent; text-decoration: none; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: #fff; }
        .nav-link.active { background: rgba(67, 97, 238, 0.15); color: #4361ee; border-left-color: #4361ee; }
        .nav-link i { font-size: 1.2rem; margin-right: 15px; }
        
        .main-content { margin-left: var(--sidebar-width); padding: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .breadcrumb-item a { text-decoration: none; color: var(--primary-color); }

        .bg-success-soft { background-color: #dcfce7; }

        @media (max-width: 992px) {
            .sidebar { left: -260px; transition: 0.3s; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h4 class="fw-bold mb-0">School<span class="text-primary">RMS</span></h4>
        <small class="text-muted text-uppercase fw-bold" style="font-size: 0.65rem;">Accounts Department</small>
    </div>
    <div class="py-4">
        <a href="dashboard.php" class="nav-link">
            <i class="bi bi-grid-1x2-fill"></i> Dashboard
        </a>
        <a href="billing.php" class="nav-link active">
            <i class="bi bi-receipt-cutoff"></i> Fee Management
        </a>
        <a href="bill_items.php" class="nav-link">
            <i class="bi bi-list-check"></i> Bill Items
        </a>
        <a href="payments.php" class="nav-link">
            <i class="bi bi-credit-card-2-front"></i> Payments
        </a>
        <div class="mt-5 px-4">
            <a href="logout.php" class="btn btn-danger w-100 rounded-pill py-2">
                <i class="bi bi-box-arrow-left me-2"></i> Logout
            </a>
        </div>
    </div>
</div>

<div class="main-content">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="billing.php">Fee Management</a></li>
            <li class="breadcrumb-item active">Class Bills</li>
        </ol>
    </nav>

    <div class="d-flex justify-content-between align-items-end mb-4">
        <div>
            <h3 class="fw-bold mb-1"><?= htmlspecialchars($info['class_name'] ?? 'Class') ?> Billing Details</h3>
            <p class="text-muted mb-0">
                <span class="badge bg-dark me-2"><?= htmlspecialchars($info['session_name'] ?? 'Session') ?></span>
                <span class="badge bg-primary"><?= $term_names[$term_id] ?? 'Term' ?></span>
            </p>
        </div>
        <div class="d-flex gap-2">
            <a href="generate_invoice.php?class_id=<?= $class_id ?>&session=<?= $session_id ?>&term=<?= $term_id ?>" 
               target="_blank" class="btn btn-primary shadow-sm">
                <i class="bi bi-printer-fill me-2"></i> Print All Invoices
            </a>
            <button class="btn btn-white border shadow-sm d-lg-none" onclick="document.getElementById('sidebar').classList.toggle('active')">
                <i class="bi bi-list"></i>
            </button>
        </div>
    </div>

    <div class="card p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h6 class="fw-bold mb-0">Student Invoice List (<?= count($student_bills) ?> Students)</h6>
            <div class="input-group input-group-sm" style="max-width: 250px;">
                <span class="input-group-text bg-light border-0"><i class="bi bi-search"></i></span>
                <input type="text" id="studentSearch" class="form-control bg-light border-0" placeholder="Search name or ID...">
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle" id="studentTable">
                <thead class="bg-light">
                    <tr class="text-muted small">
                        <th>ADM NO.</th>
                        <th>STUDENT NAME</th>
                        <th class="text-center">TERM BILL</th>
                        <th class="text-center">BALANCE</th>
                        <th class="text-end">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($student_bills)): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">No bill records found for this selection.</td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($student_bills as $bill): ?>
                    <tr>
                        <td class="text-muted small fw-bold"><?= htmlspecialchars($bill['admission_no']) ?></td>
                        <td>
                            <div class="fw-bold"><?= htmlspecialchars($bill['student_name']) ?></div>
                        </td>
                        <td class="text-center fw-bold text-dark">
                            ₦<?= number_format($bill['total_bill'], 2) ?>
                        </td>
                        <td class="text-center">
                            <?php if ($bill['total_balance'] <= 0): ?>
                                <span class="badge bg-success-soft text-success rounded-pill px-3">Cleared</span>
                            <?php else: ?>
                                <span class="text-danger fw-bold">₦<?= number_format($bill['total_balance'], 2) ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <div class="btn-group">
                                <a href="update_student_bill.php?student_id=<?= $bill['student_id'] ?>&session=<?= $session_id ?>&term=<?= $term_id ?>" 
                                   class="btn btn-sm btn-outline-secondary" title="Edit Items">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="generate_invoice.php?student_id=<?= $bill['student_id'] ?>&session=<?= $session_id ?>&term=<?= $term_id ?>" 
                                   target="_blank" class="btn btn-sm btn-dark" title="Print Individual Invoice">
                                    <i class="bi bi-printer me-1"></i> Print
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Simple table search filter
    document.getElementById('studentSearch').addEventListener('keyup', function() {
        let filter = this.value.toUpperCase();
        let rows = document.querySelector("#studentTable tbody").rows;
        
        for (let i = 0; i < rows.length; i++) {
            let nameCol = rows[i].cells[1].textContent.toUpperCase();
            let admCol = rows[i].cells[0].textContent.toUpperCase();
            if (nameCol.indexOf(filter) > -1 || admCol.indexOf(filter) > -1) {
                rows[i].style.display = "";
            } else {
                rows[i].style.display = "none";
            }      
        }
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 