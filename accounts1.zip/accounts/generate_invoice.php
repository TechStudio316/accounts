<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

// --- 1. PARAMETER RECOVERY ---
// Supports both 'session_id' and 'session' to prevent errors from different links
$student_id = $_GET['student_id'] ?? null;
$class_id   = $_GET['class_id']   ?? null;
$session_id = $_GET['session_id'] ?? $_GET['session'] ?? null;
$term_id    = $_GET['term_id']    ?? $_GET['term']    ?? null;

if (!$session_id || !$term_id) {
    die("<div style='padding:20px; border:1px solid red; color:red; font-family:sans-serif;'>
            <strong>Error:</strong> Session and Term parameters are required to generate invoices.<br>
            <a href='billing.php'>Return to Billing</a>
         </div>");
}

// --- 2. DATA FETCHING ---
// Fetch School Info
$school = $pdo->query("SELECT * FROM school_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// Fetch Session Details
$stmt_sess = $pdo->prepare("SELECT name, next_term_begins FROM sessions WHERE id = ?");
$stmt_sess->execute([$session_id]);
$sess_row = $stmt_sess->fetch(PDO::FETCH_ASSOC);

$display_session = $sess_row['name'] ?? "Current Session"; 
$resumption_date = (!empty($sess_row['next_term_begins'])) 
    ? date('jS F, Y', strtotime($sess_row['next_term_begins'])) 
    : 'the start of next term';

// Fetch Student(s) based on input
$students = [];
if ($student_id) {
    $stmt = $pdo->prepare("SELECT s.*, c.name as class_name FROM students s JOIN classes c ON s.class_id = c.id WHERE s.id = ?");
    $stmt->execute([$student_id]);
} elseif ($class_id) {
    $stmt = $pdo->prepare("SELECT s.*, c.name as class_name FROM students s JOIN classes c ON s.class_id = c.id WHERE s.class_id = ?");
    $stmt->execute([$class_id]);
} else {
    die("No student or class specified.");
}
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) die("No records found for the selection.");

$term_names = [1 => "First Term", 2 => "Second Term", 3 => "Third Term"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice - <?= htmlspecialchars($school['name'] ?? 'School') ?></title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; background: #f0f0f0; color: #333; }
        .page { background: #fff; width: 210mm; margin: 10px auto; padding: 10mm; box-sizing: border-box; }
        
        /* Layout for bulk printing: 2 per page if many, 1 per page if single */
        <?php if (count($students) > 1): ?>
            .invoice-block { height: 140mm; border-bottom: 1px dashed #ccc; padding: 5mm 0; overflow: hidden; page-break-inside: avoid; }
            .invoice-block:nth-child(2n) { border-bottom: none; page-break-after: always; }
        <?php else: ?>
            .invoice-block { min-height: 270mm; padding: 5mm 0; }
        <?php endif; ?>

        .invoice-header { display: flex; align-items: center; border-bottom: 3px solid #000; padding-bottom: 10px; margin-bottom: 15px; }
        .logo-box { width: 80px; height: 80px; margin-right: 20px; }
        .logo-box img { width: 100%; height: 100%; object-fit: contain; }
        .school-branding h1 { margin: 0; font-size: 22px; text-transform: uppercase; color: #000; }
        .school-branding p { margin: 2px 0; font-size: 12px; color: #555; }

        .invoice-meta { display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 13px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        .meta-col strong { color: #777; font-size: 10px; text-transform: uppercase; display: block; }

        .table-fees { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        .table-fees th { background: #eee; text-align: left; padding: 8px; font-size: 11px; text-transform: uppercase; border: 1px solid #ddd; }
        .table-fees td { padding: 8px; border: 1px solid #ddd; font-size: 13px; }

        .summary-wrapper { display: flex; justify-content: flex-end; margin-top: 5px; }
        .summary-table { width: 280px; font-size: 13px; }
        .summary-row { display: flex; justify-content: space-between; padding: 4px 0; border-bottom: 1px solid #f9f9f9; }
        .grand-total-row { background: #000; color: #fff; padding: 8px; font-weight: bold; font-size: 15px; border-radius: 4px; margin-top: 5px; }

        .bank-info { background: #f9f9f9; border: 1px solid #ddd; padding: 10px; border-radius: 4px; font-size: 12px; margin-top: 15px; }
        .resumption-alert { color: #b91c1c; font-weight: bold; margin-top: 10px; font-size: 12px; border-left: 3px solid #b91c1c; padding-left: 8px; }

        @media print {
            body { background: #fff; }
            .page { margin: 0; width: 100%; padding: 5mm; }
            .no-print { display: none; }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="no-print" style="background:#333; color:#fff; padding:10px; text-align:center; position:sticky; top:0;">
        Currently viewing <strong><?= count($students) ?></strong> invoices. 
        <button onclick="window.print()" style="padding:5px 15px; cursor:pointer;">Print Now</button>
        <button onclick="window.history.back()" style="padding:5px 15px; cursor:pointer;">Back</button>
    </div>

    <div class="page">
        <?php foreach ($students as $st): 
            // 1. Fetch Current Term Specific Items
            $stmt_b = $pdo->prepare("SELECT item_name, total_amount FROM student_bills WHERE student_id = ? AND session_id = ? AND term_id = ?");
            $stmt_b->execute([$st['id'], $session_id, $term_id]);
            $items = $stmt_b->fetchAll(PDO::FETCH_ASSOC);
            
            $current_total = 0;
            foreach($items as $i) $current_total += $i['total_amount'];
            
            // 2. Fetch Arrears/Credit from ALL other terms
            $stmt_arr = $pdo->prepare("SELECT SUM(balance) FROM student_bills WHERE student_id = ? AND NOT (session_id = ? AND term_id = ?)");
            $stmt_arr->execute([$st['id'], $session_id, $term_id]);
            $ledger_sum = $stmt_arr->fetchColumn() ?: 0;

            $total_due = $current_total + $ledger_sum;
        ?>
        <div class="invoice-block">
            <div class="invoice-header">
                <div class="logo-box">
                    <img src="../public/uploads/school_logo.png" alt="Logo" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
                </div>
                <div class="school-branding">
                    <h1><?= htmlspecialchars($school['name'] ?? 'SCHOOL NAME') ?></h1>
                    <p><?= htmlspecialchars($school['address'] ?? 'School Address Line') ?></p>
                    <p>Tel: <?= htmlspecialchars($school['phone'] ?? 'N/A') ?> | Email: <?= htmlspecialchars($school['email'] ?? 'N/A') ?></p>
                </div>
            </div>

            <div class="invoice-meta">
                <div class="meta-col">
                    <strong>Student / Payer:</strong>
                    <span style="font-size: 15px; font-weight: bold;"><?= htmlspecialchars($st['name']) ?></span><br>
                    ID: <?= htmlspecialchars($st['admission_no']) ?> | Class: <?= htmlspecialchars($st['class_name']) ?>
                </div>
                <div class="meta-col" style="text-align: right;">
                    <strong>Termly Bill:</strong>
                    <?= htmlspecialchars($display_session) ?> - <?= $term_names[$term_id] ?? 'Term '.$term_id ?><br>
                    Issued: <?= date('d M, Y') ?>
                </div>
            </div>

            <table class="table-fees">
                <thead>
                    <tr>
                        <th width="70%">Description</th>
                        <th style="text-align: right;">Amount (₦)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($items)): ?>
                        <tr><td colspan="2" style="text-align:center; color:#999;">No specific fees found for this term.</td></tr>
                    <?php else: ?>
                        <?php foreach($items as $i): ?>
                        <tr>
                            <td><?= htmlspecialchars($i['item_name']) ?></td>
                            <td style="text-align: right;"><?= number_format($i['total_amount'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="summary-wrapper">
                <div class="summary-table">
                    <div class="summary-row">
                        <span>Current Term Sub-total:</span> 
                        <span>₦<?= number_format($current_total, 2) ?></span>
                    </div>

                    <?php if ($ledger_sum != 0): ?>
                    <div class="summary-row" style="color: <?= ($ledger_sum > 0) ? '#b91c1c' : '#15803d' ?>;">
                        <span><?= ($ledger_sum > 0) ? 'Brought Forward (Arrears):' : 'Advance Credit:' ?></span> 
                        <span>₦<?= number_format(abs($ledger_sum), 2) ?></span>
                    </div>
                    <?php endif; ?>

                    <div class="summary-row grand-total-row">
                        <span>TOTAL PAYABLE:</span> 
                        <span>₦<?= number_format(max(0, $total_due), 2) ?></span>
                    </div>
                </div>
            </div>

            <div class="bank-info">
                <strong>PAYMENT INFORMATION:</strong><br>
                Bank: <?= htmlspecialchars($school['bank_name'] ?? '---') ?> | 
                Account: <strong><?= htmlspecialchars($school['account_no'] ?? '---') ?></strong> | 
                Name: <?= htmlspecialchars($school['account_name'] ?? '---') ?>
            </div>

            <?php if ($total_due > 0): ?>
            <div class="resumption-alert">
                Resumption Date: <?= htmlspecialchars($resumption_date) ?>. 
                Please ensure full or significant partial payment is made before this date.
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</body>
</html>