<?php
require_once __DIR__ . '/includes/db.php';
require_once 'includes/functions.php';

// 1. SECURITY CHECK (Using your new function from functions.php)
checkAccess();

$message = "";
$term_names = [1 => "First Term", 2 => "Second Term", 3 => "Third Term"];

// --- 1. HANDLE BATCH DELETION ---
if (isset($_GET['delete_batch']) && $_SESSION['role'] === 'admin') {
    $del_class = $_GET['class_id'];
    $del_session = $_GET['session_id'];
    $del_term = $_GET['term_id'];

    try {
        // Safety check: Prevent deletion if payments exist
        $check_payments = $pdo->prepare("
            SELECT COUNT(*) FROM payments p
            JOIN student_bills sb ON p.bill_id = sb.id
            JOIN students st ON sb.student_id = st.id
            WHERE st.class_id = ? AND sb.session_id = ? AND sb.term_id = ?
        ");
        $check_payments->execute([$del_class, $del_session, $del_term]);
        
        if ($check_payments->fetchColumn() > 0) {
            $message = "<div class='alert alert-danger border-0 shadow-sm'>Cannot delete: Payments have already been recorded against these bills.</div>";
        } else {
            $del_stmt = $pdo->prepare("
                DELETE sb FROM student_bills sb
                JOIN students st ON sb.student_id = st.id
                WHERE st.class_id = ? AND sb.session_id = ? AND sb.term_id = ?
            ");
            $del_stmt->execute([$del_class, $del_session, $del_term]);
            
            // --- AUDIT LOG ---
            logAudit($pdo, "DELETED BILLING BATCH", "Class ID: $del_class, Session: $del_session, Term: $del_term");
            
            $message = "<div class='alert alert-success border-0 shadow-sm'>Batch billing history deleted successfully.</div>";
        }
    } catch (PDOException $e) {
        $message = "<div class='alert alert-danger border-0 shadow-sm'>Error: " . $e->getMessage() . "</div>";
    }
}

// --- 2. HANDLE BILL GENERATION (OPTIMIZED) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_bills'])) {
    $class_id = $_POST['class_id'];
    $session_id = $_POST['session_id'];
    $term_id = $_POST['term_id'];
    $selected_students = $_POST['student_ids'] ?? [];

    try {
        $stmt_fees = $pdo->prepare("SELECT item_name, amount FROM fee_items WHERE class_id = ? AND session_id = ? AND term = ?");
        $stmt_fees->execute([$class_id, $session_id, $term_id]);
        $fees = $stmt_fees->fetchAll();

        if (!empty($selected_students)) {
            $placeholders = implode(',', array_fill(0, count($selected_students), '?'));
            $stmt_students = $pdo->prepare("SELECT id FROM students WHERE id IN ($placeholders)");
            $stmt_students->execute($selected_students);
        } else {
            $stmt_students = $pdo->prepare("SELECT id FROM students WHERE class_id = ?");
            $stmt_students->execute([$class_id]);
        }
        $students = $stmt_students->fetchAll();

        if (empty($fees)) {
            $message = "<div class='alert alert-warning border-0 shadow-sm'>No Fee Items configured for this class/term.</div>";
        } elseif (empty($students)) {
            $message = "<div class='alert alert-warning border-0 shadow-sm'>No students found for this selection.</div>";
        } else {
            $pdo->beginTransaction();
            
            $count = 0;
            $check = $pdo->prepare("SELECT id FROM student_bills WHERE student_id = ? AND item_name = ? AND session_id = ? AND term_id = ?");
            $ins = $pdo->prepare("INSERT INTO student_bills (student_id, item_name, total_amount, balance, session_id, term_id) VALUES (?, ?, ?, ?, ?, ?)");

            foreach ($students as $student) {
                foreach ($fees as $fee) {
                    $check->execute([$student['id'], $fee['item_name'], $session_id, $term_id]);
                    if (!$check->fetch()) {
                        $ins->execute([$student['id'], $fee['item_name'], $fee['amount'], $fee['amount'], $session_id, $term_id]);
                        $count++;
                    }
                    $check->closeCursor();
                }
            }
            
            $pdo->commit();

            // --- AUDIT LOG ---
            logAudit($pdo, "GENERATED BILLS", "Generated $count bill records for Class ID: $class_id, Term: $term_id");

            $message = "<div class='alert alert-success border-0 shadow-sm'>Successfully generated $count bill records.</div>";
        }
    } catch (PDOException $e) { 
        if($pdo->inTransaction()) $pdo->rollBack();
        $message = "<div class='alert alert-danger border-0 shadow-sm'>Error: " . $e->getMessage() . "</div>"; 
    }
}

// --- 3. FETCH DATA FOR HISTORY ---
$f_class = $_GET['f_class'] ?? '';
$f_session = $_GET['f_session'] ?? '';
$f_term = $_GET['f_term'] ?? '';

try {
    $classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();
    $sessions = $pdo->query("SELECT id, name FROM sessions ORDER BY name DESC")->fetchAll();
    $term_activations = $pdo->query("SELECT DISTINCT term_id FROM term_activations ORDER BY term_id ASC")->fetchAll();

    $list_query = "SELECT st.class_id, c.name as class_name, s.name as session_name, sb.term_id, sb.session_id,
                          COUNT(DISTINCT sb.student_id) as student_count, 
                          SUM(sb.total_amount) as total_value
                   FROM student_bills sb
                   JOIN students st ON sb.student_id = st.id
                   JOIN classes c ON st.class_id = c.id
                   JOIN sessions s ON sb.session_id = s.id
                   WHERE 1=1";
    
    $list_params = [];
    if ($f_class) { $list_query .= " AND st.class_id = ?"; $list_params[] = $f_class; }
    if ($f_session) { $list_query .= " AND sb.session_id = ?"; $list_params[] = $f_session; }
    if ($f_term) { $list_query .= " AND sb.term_id = ?"; $list_params[] = $f_term; }

    $list_query .= " GROUP BY st.class_id, sb.session_id, sb.term_id ORDER BY s.name DESC, sb.term_id DESC";
    $recent_billings = $pdo->prepare($list_query);
    $recent_billings->execute($list_params);
    $bill_logs = $recent_billings->fetchAll();

} catch (PDOException $e) { 
    error_log($e->getMessage());
    die("A database error occurred."); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Management | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-width: 260px; --primary-color: #4361ee; --dark-blue: #0f172a; }
        body { background-color: #f1f5f9; font-family: 'Inter', sans-serif; overflow-x: hidden; }
        .sidebar { width: var(--sidebar-width); height: 100vh; position: fixed; left: 0; top: 0; background: var(--dark-blue); color: #fff; z-index: 1000; }
        .sidebar-header { padding: 25px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .nav-link { color: #94a3b8; padding: 12px 25px; display: flex; align-items: center; border-left: 4px solid transparent; text-decoration: none; }
        .nav-link.active { background: rgba(67, 97, 238, 0.15); color: #4361ee; border-left-color: #4361ee; }
        .main-content { margin-left: var(--sidebar-width); padding: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        @media (max-width: 992px) { .sidebar { left: -260px; } .main-content { margin-left: 0; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <h4 class="fw-bold mb-0">School<span class="text-primary">RMS</span></h4>
        <small class="text-muted text-uppercase fw-bold" style="font-size: 0.65rem;">Accounts Department</small>
    </div>
    <nav class="nav flex-column gap-1">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link active" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0">Fee & Invoice Management</h4>
        <button class="btn btn-dark shadow-sm" data-bs-toggle="modal" data-bs-target="#individualBillModal">
            <i class="bi bi-person-plus-fill me-2"></i> Bill Specific Students
        </button>
    </div>

    <?= $message ?>

    <div class="row g-4">
        <div class="col-xl-4 col-lg-5">
            <div class="card p-4 h-100">
                <h6 class="fw-bold mb-4">Generate Class Bills</h6>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">1. TARGET CLASS</label>
                        <select name="class_id" class="form-select border-0 bg-light py-2" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach($classes as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">2. SESSION</label>
                        <select name="session_id" class="form-select border-0 bg-light py-2" required>
                            <?php foreach($sessions as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label class="form-label text-muted small fw-bold">3. TERM</label>
                        <select name="term_id" class="form-select border-0 bg-light py-2" required>
                            <?php foreach($term_activations as $t): ?>
                                <option value="<?= $t['term_id'] ?>">
                                    <?= $term_names[$t['term_id']] ?? "Term ".$t['term_id'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" name="generate_bills" class="btn btn-primary w-100 py-3 fw-bold">
                        <i class="bi bi-lightning-charge-fill me-2"></i> Generate Class Batch
                    </button>
                </form>
            </div>
        </div>

        <div class="col-xl-8 col-lg-7">
            <div class="card p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h6 class="fw-bold mb-0">Batch Billing History</h6>
                    <form method="GET" class="d-flex gap-2">
                        <select name="f_class" class="form-select form-select-sm bg-light border-0">
                            <option value="">All Classes</option>
                            <?php foreach($classes as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= $f_class == $c['id'] ? 'selected' : '' ?>><?= $c['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-dark btn-sm px-3">Filter</button>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="bg-light">
                            <tr class="text-muted small">
                                <th>CLASS</th>
                                <th>SESSION & TERM</th>
                                <th class="text-center">STUDENTS</th>
                                <th>VALUE</th>
                                <th class="text-end">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($bill_logs as $log): ?>
                            <tr>
                                <td class="fw-bold"><?= htmlspecialchars($log['class_name']) ?></td>
                                <td>
                                    <div class="small fw-bold"><?= $term_names[$log['term_id']] ?? "Unknown Term" ?></div>
                                    <div class="text-muted small"><?= htmlspecialchars($log['session_name']) ?></div>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-primary rounded-pill"><?= $log['student_count'] ?></span>
                                </td>
                                <td class="text-success fw-bold">₦<?= number_format($log['total_value'], 2) ?></td>
                                <td class="text-end">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-light border dropdown-toggle" data-bs-toggle="dropdown">Action</button>
                                        <ul class="dropdown-menu shadow-sm">
                                            <li><a class="dropdown-item" href="view_class_bills.php?class_id=<?= $log['class_id'] ?>&session=<?= $log['session_id'] ?>&term=<?= $log['term_id'] ?>"><i class="bi bi-eye me-2"></i> View Bills</a></li>
                                            <li><a class="dropdown-item" href="generate_invoice.php?class_id=<?= $log['class_id'] ?>&session_id=<?= $log['session_id'] ?>&term_id=<?= $log['term_id'] ?>"><i class="bi bi-printer me-2"></i> Print Invoices</a></li>
                                            <?php if($_SESSION['role'] === 'admin'): ?>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item text-danger" href="javascript:void(0)" 
                                                   onclick="confirmDelete('<?= $log['class_id'] ?>', '<?= $log['session_id'] ?>', '<?= $log['term_id'] ?>', '<?= addslashes($log['class_name']) ?>')">
                                                    <i class="bi bi-trash3 me-2"></i> Delete Batch
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="individualBillModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Bill Specific Students</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="small fw-bold">CLASS</label>
                            <select name="class_id" class="form-select" required onchange="loadStudents(this.value)">
                                <option value="">-- Select --</option>
                                <?php foreach($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= $c['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="small fw-bold">SESSION</label>
                            <select name="session_id" class="form-select" required>
                                <?php foreach($sessions as $s): ?>
                                    <option value="<?= $s['id'] ?>"><?= $s['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="small fw-bold">TERM</label>
                            <select name="term_id" class="form-select" required>
                                <?php foreach($term_activations as $t): ?>
                                    <option value="<?= $t['term_id'] ?>"><?= $term_names[$t['term_id']] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <h6 class="fw-bold mb-3">Select Students</h6>
                    <div id="student_list" class="row g-2" style="max-height: 250px; overflow-y: auto;">
                        <p class="text-muted small p-3">Select a class first to load students...</p>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="generate_bills" class="btn btn-primary px-4">Generate Selected Bills</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function confirmDelete(classId, sessionId, termId, className) {
        if (confirm(`CRITICAL WARNING!\n\nThis will delete ALL bill records for ${className}. This cannot be undone. \n\nContinue?`)) {
            window.location.href = `billing.php?delete_batch=1&class_id=${classId}&session_id=${sessionId}&term_id=${termId}`;
        }
    }

    async function loadStudents(classId) {
        const container = document.getElementById('student_list');
        if (!classId) {
            container.innerHTML = '<p class="text-muted small p-3">Select a class first...</p>';
            return;
        }
        container.innerHTML = '<div class="p-3">Loading students...</div>';
        try {
            const response = await fetch(`get_students_by_class.php?class_id=${classId}`);
            const data = await response.json();
            if (data.length === 0) {
                container.innerHTML = '<p class="text-warning p-3">No students in this class.</p>';
                return;
            }
            let html = '';
            data.forEach(s => {
                html += `
                    <div class="col-md-6">
                        <div class="form-check p-2 border rounded">
                            <input class="form-check-input ms-0 me-2" type="checkbox" name="student_ids[]" value="${s.id}" id="s${s.id}">
                            <label class="form-check-label small" for="s${s.id}">${s.name} (${s.admission_no})</label>
                        </div>
                    </div>`;
            });
            container.innerHTML = html;
        } catch (e) {
            container.innerHTML = '<p class="text-danger p-3">Error loading students. Ensure get_students_by_class.php exists.</p>';
        }
    }
</script>
</body>
</html>