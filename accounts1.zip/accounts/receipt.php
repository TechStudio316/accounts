<?php
// 1. Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id'])) exit("Access Denied");
require_once __DIR__ . '/includes/db.php';

$payment_id = $_GET['id'] ?? 0;

try {
    // 2. Fetch detailed payment info 
    // Joining term_activations on b.term_id and using ta.termname
    $stmt = $pdo->prepare("SELECT p.*, s.id as sid, s.name as student_name, s.admission_no, 
                                  c.name as class_name, b.item_name, 
                                  sess.name as session_name, ta.term_name as term_name
                           FROM payments p
                           JOIN students s ON p.student_id = s.id
                           JOIN classes c ON s.class_id = c.id
                           JOIN student_bills b ON p.bill_id = b.id
                           LEFT JOIN sessions sess ON b.session_id = sess.id
                           LEFT JOIN term_activations ta ON b.term_id = ta.id
                           WHERE p.id = ?");
    $stmt->execute([$payment_id]);
    $pay = $stmt->fetch();

    if (!$pay) exit("Receipt not found.");

    // 3. Fetch TOTAL OUTSTANDING for ALL items for this student
    $stmt_debt = $pdo->prepare("SELECT SUM(balance) FROM student_bills WHERE student_id = ?");
    $stmt_debt->execute([$pay['sid']]);
    $total_outstanding = $stmt_debt->fetchColumn() ?: 0;

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt_<?= htmlspecialchars($pay['reference_no'] ?? 'Unknown') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #eee; font-family: 'Courier New', Courier, monospace; }
        .receipt-card { background: white; width: 450px; margin: 30px auto; padding: 30px; border: 1px solid #ddd; position: relative; }
        .school-name { font-size: 1.4rem; font-weight: bold; text-transform: uppercase; }
        .line { border-top: 1px dashed #000; margin: 15px 0; }
        .balance-box { background: #f9f9f9; border: 1px solid #000; padding: 10px; margin-top: 15px; }
        .label-text { font-weight: bold; width: 100px; display: inline-block; }
        @media print { 
            .no-print { display: none; } 
            body { background: white; } 
            .receipt-card { border: none; margin: 0; width: 100%; } 
        }
    </style>
</head>
<body>

<div class="no-print text-center mt-3">
    <button onclick="window.print()" class="btn btn-primary">Print Receipt</button>
    <a href="payments.php" class="btn btn-secondary">Back</a>
</div>

<div class="receipt-card">
    <div class="text-center">
        <img src="../public/uploads/school_logo.png" style="height: 60px; margin-bottom: 5px;" onerror="this.src='https://via.placeholder.com/60?text=LOGO'">
        <div class="school-name">BGB Group of Schools</div>
        <p class="small mb-0">Official Payment Receipt</p>
    </div>
    
    <div class="line"></div>
    
    <div class="row small">
        <div class="col-6"><strong>Date:</strong> <?= date('d M, Y', strtotime($pay['payment_date'] ?? 'now')) ?></div>
        <div class="col-6 text-end"><strong>Ref:</strong> <?= htmlspecialchars($pay['reference_no'] ?? '') ?></div>
    </div>
    
    <div class="mt-3 small">
        <p class="mb-1"><span class="label-text">Student:</span> <?= htmlspecialchars($pay['student_name'] ?? '') ?></p>
        <p class="mb-1"><span class="label-text">Adm No:</span> <?= htmlspecialchars($pay['admission_no'] ?? '') ?></p>
        <p class="mb-1"><span class="label-text">Class:</span> <?= htmlspecialchars($pay['class_name'] ?? '') ?></p>
        <p class="mb-1"><span class="label-text">Session:</span> <?= htmlspecialchars($pay['session_name'] ?? 'N/A') ?></p>
        <p class="mb-1"><span class="label-text">Term:</span> <?= htmlspecialchars($pay['term_name'] ?? 'N/A') ?></p>
    </div>
    
    <div class="line"></div>
    
    <table class="table table-borderless table-sm small">
        <thead>
            <tr>
                <th>Payment Description</th>
                <th class="text-end">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?= htmlspecialchars($pay['item_name'] ?? '') ?>
                    <br><small class="text-muted">(<?= htmlspecialchars($pay['term_name'] ?? 'N/A') ?>)</small>
                </td>
                <td class="text-end">₦<?= number_format($pay['amount_paid'] ?? 0, 2) ?></td>
            </tr>
        </tbody>
    </table>
    
    <div class="line"></div>
    
    <div class="d-flex justify-content-between">
        <span class="fw-bold">TOTAL PAID:</span>
        <span class="fw-bold">₦<?= number_format($pay['amount_paid'] ?? 0, 2) ?></span>
    </div>

    <div class="balance-box text-center">
        <p class="small mb-1 text-uppercase">Total Outstanding Balance</p>
        <h4 class="fw-bold mb-0 <?= ($total_outstanding > 0) ? 'text-danger' : 'text-success' ?>">
            ₦<?= number_format($total_outstanding, 2) ?>
        </h4>
        <?php if($total_outstanding <= 0): ?>
            <small class="text-success fw-bold">ALL BILLS CLEARED</small>
        <?php endif; ?>
    </div>
    
    <div class="mt-4 text-center small">
        <p><em>Thank you for your payment!</em></p>
        <div class="line"></div>
        <p style="font-size: 10px;">BGB Group of Schools - Raising future Greats</p>
    </div>
</div>

</body>
</html>