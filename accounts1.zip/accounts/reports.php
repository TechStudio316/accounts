<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

// --- 1. DATA CALCULATIONS ---
try {
    // Total Fees Collected
    $total_revenue = $pdo->query("SELECT SUM(amount_paid) FROM payments")->fetchColumn() ?: 0;

    // Total Expenses
    $total_expenses = $pdo->query("SELECT SUM(amount) FROM expenses")->fetchColumn() ?: 0;

    // Outstanding Fees
    $total_outstanding = $pdo->query("SELECT SUM(balance) FROM student_bills")->fetchColumn() ?: 0;

    // Net Profit
    $net_profit = $total_revenue - $total_expenses;

    // Class Breakdown
    $class_data = $pdo->query("SELECT c.name, 
                                SUM(sb.total_amount) as billed, 
                                SUM(sb.paid_amount) as paid, 
                                SUM(sb.balance) as debt
                                FROM classes c
                                LEFT JOIN students s ON s.class_id = c.id
                                LEFT JOIN student_bills sb ON sb.student_id = s.id
                                GROUP BY c.id ORDER BY c.name ASC")->fetchAll();

    // Expense Categories for Chart
    $expense_cats = $pdo->query("SELECT category, SUM(amount) as total FROM expenses GROUP BY category")->fetchAll();
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Financial Analysis | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f1f5f9; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: #0f172a; color: white; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
        .stat-card { transition: transform 0.2s; }
        .stat-card:hover { transform: translateY(-5px); }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <h6 class="fw-bold">SchoolRMS | Finance</h6>
    </div>
    <nav class="nav flex-column px-3">
        <a class="nav-link text-white-50" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link text-white-50" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link text-white-50" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>
        <a class="nav-link text-white fw-bold" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Reports</a>
        <a class="nav-link text-danger mt-5" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">Financial Analysis Report</h3>
        <button class="btn btn-outline-dark" onclick="window.print()"><i class="bi bi-printer me-2"></i> Print Report</button>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card p-3 bg-white border-start border-4 border-success stat-card">
                <p class="small text-muted mb-1">Total Income (Fees)</p>
                <h4 class="fw-bold text-success mb-0">₦<?= number_format($total_revenue, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 bg-white border-start border-4 border-danger stat-card">
                <p class="small text-muted mb-1">Total Expenses</p>
                <h4 class="fw-bold text-danger mb-0">₦<?= number_format($total_expenses, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 bg-primary text-white stat-card">
                <p class="small mb-1 opacity-75">Net Profit</p>
                <h4 class="fw-bold mb-0">₦<?= number_format($net_profit, 2) ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 bg-warning text-dark stat-card">
                <p class="small mb-1 opacity-75">Uncollected Fees</p>
                <h4 class="fw-bold mb-0">₦<?= number_format($total_outstanding, 2) ?></h4>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-7">
            <div class="card p-4 h-100">
                <h6 class="fw-bold mb-4">Revenue vs Expenses Breakdown</h6>
                <canvas id="financeChart" height="250"></canvas>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card p-4 h-100">
                <h6 class="fw-bold mb-4">Expense by Category</h6>
                <canvas id="expensePieChart" height="250"></canvas>
            </div>
        </div>

        <div class="col-12">
            <div class="card p-4">
                <h6 class="fw-bold mb-3">Class-wise Collection & Debt</h6>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Class Name</th>
                                <th>Total Billed</th>
                                <th>Total Collected</th>
                                <th>Outstanding Debt</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($class_data as $row): 
                                $percent = ($row['billed'] > 0) ? ($row['paid'] / $row['billed']) * 100 : 0;
                            ?>
                            <tr>
                                <td class="fw-bold"><?= htmlspecialchars($row['name'] ?? 'N/A') ?></td>
                                <td>₦<?= number_format($row['billed'] ?? 0, 2) ?></td>
                                <td class="text-success">₦<?= number_format($row['paid'] ?? 0, 2) ?></td>
                                <td class="text-danger fw-bold">₦<?= number_format($row['debt'] ?? 0, 2) ?></td>
                                <td>
                                    <div class="progress" style="height: 8px; width: 100px;">
                                        <div class="progress-bar bg-success" style="width: <?= $percent ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?= round($percent) ?>% Paid</small>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // 1. Bar Chart: Revenue vs Expenses
    const ctx = document.getElementById('financeChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Fees Collected', 'Total Expenses', 'Net Profit'],
            datasets: [{
                label: 'Amount (₦)',
                data: [<?= $total_revenue ?>, <?= $total_expenses ?>, <?= $net_profit ?>],
                backgroundColor: ['#198754', '#dc3545', '#0d6efd'],
                borderRadius: 10
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });

    // 2. Pie Chart: Expenses Categories
    const ctx2 = document.getElementById('expensePieChart').getContext('2d');
    new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: [<?php foreach($expense_cats as $c) echo "'".$c['category']."',"; ?>],
            datasets: [{
                data: [<?php foreach($expense_cats as $c) echo $c['total'].","; ?>],
                backgroundColor: ['#6366f1', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6']
            }]
        }
    });
</script>

</body>
</html>