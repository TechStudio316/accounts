<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

// Fetch School Info for Branding
$school = $pdo->query("SELECT name FROM school_info LIMIT 1")->fetch();
$school_name = $school['name'] ?? 'SchoolRMS';
$school_logo = "/public/uploads/school_logo.png";

$message = "";

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_expense'])) {
    $title = $_POST['title'];
    $amount = $_POST['amount'];
    $category = $_POST['category'];
    $date = $_POST['expense_date'];
    $desc = $_POST['description'];
    $method = $_POST['payment_method'];

    try {
        $pdo->beginTransaction();

        // 1. Insert into expenses table
        $stmt = $pdo->prepare("INSERT INTO expenses (title, amount, category, expense_date, description, payment_method) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $amount, $category, $date, $desc, $method]);
        
        // 2. --- ADD AUDIT LOG ENTRY ---
        $user_id = $_SESSION['user_id'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $logDetails = "Title: $title | Category: $category | Method: $method | Amount: ₦" . number_format($amount, 2);
        
        $logStmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details, ip_address, created_at) VALUES (?, ?, ?, ?, NOW())");
        $logStmt->execute([$user_id, 'Expense Recorded', $logDetails, $ip]);
        
        $pdo->commit();
        
        $message = "<div class='alert alert-success alert-dismissible fade show border-0 shadow-sm' role='alert'>
                        <i class='bi bi-check-circle-fill me-2'></i> Expense recorded and audit trail updated!
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $message = "<div class='alert alert-danger border-0 shadow-sm'>Error: " . $e->getMessage() . "</div>";
    }
}

// Fetch Expenses
$expenses = $pdo->query("SELECT * FROM expenses ORDER BY expense_date DESC LIMIT 50")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Management | <?= htmlspecialchars($school_name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; transition: 0.3s; z-index: 1000; overflow-y: auto; }
        .main-content { margin-left: 260px; padding: 30px; transition: 0.3s; }
        .nav-link { color: #94a3b8; padding: 10px 20px; border-radius: 8px; margin: 2px 15px; text-decoration: none; display: block; font-size: 0.9rem; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: white; }
        .nav-link.active { background: var(--primary-blue); color: white; }
        .menu-label { font-size: 0.7rem; font-weight: 700; color: #475569; margin: 15px 25px 5px; text-transform: uppercase; letter-spacing: 1px; }
        .card { border: none; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        @media (max-width: 992px) { .sidebar { left: -260px; } .main-content { margin-left: 0; } .sidebar.active { left: 0; } }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <img src="<?= $school_logo ?>" alt="Logo" style="height: 60px; width: 60px; object-fit: contain;">
        <h6 class="mt-3 fw-bold text-truncate text-white"><?= htmlspecialchars($school_name) ?></h6>
    </div>
    <nav class="nav flex-column mb-5">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        
        <div class="menu-label">Finance & Bursary</div>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Record Payment</a>
        <a class="nav-link" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link" href="bill_items.php"><i class="bi bi-list-stars me-2"></i> Bill Items</a>
        <a class="nav-link active" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>
        
        <div class="menu-label">Debt Recovery</div>
        <a class="nav-link" href="defaulters.php"><i class="bi bi-exclamation-triangle me-2"></i> Defaulters List</a>
        <a class="nav-link" href="import_arrears.php"><i class="bi bi-person-plus me-2"></i> Import Arrears</a>
        <a class="nav-link" href="bulk_import_arrears.php"><i class="bi bi-file-earmark-spreadsheet me-2"></i> Bulk Import</a>
        
        <div class="menu-label">Reports & Audit</div>
        <a class="nav-link" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Financial Analysis</a>
        <a class="nav-link" href="audit_trail.php"><i class="bi bi-shield-check me-2"></i> Audit Trail</a>
        <a class="nav-link" href="cashbook.php"><i class="bi bi-book me-2"></i> Cashbook</a>
        
        <div class="menu-label">Administration</div>
        <a class="nav-link" href="school_settings.php"><i class="bi bi-gear me-2"></i> School Settings</a>
        <a class="nav-link text-danger mt-4" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Expense Management</h3>
            <p class="text-muted mb-0">Track school outflows and expenditures.</p>
        </div>
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#expenseModal">
            <i class="bi bi-plus-lg me-2"></i> Add New Expense
        </button>
    </div>

    <?= $message ?>

    <div class="card p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold">Recent Expenditures</h6>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th>Date</th>
                        <th>Title/Item</th>
                        <th>Category</th>
                        <th>Method</th>
                        <th>Amount</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($expenses)): ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No expenses recorded yet.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($expenses as $exp): ?>
                    <tr>
                        <td><?= date('d M, Y', strtotime($exp['expense_date'])) ?></td>
                        <td class="fw-bold"><?= htmlspecialchars($exp['title']) ?></td>
                        <td><span class="badge bg-secondary bg-opacity-10 text-secondary"><?= htmlspecialchars($exp['category']) ?></span></td>
                        <td><small class="text-uppercase fw-bold text-muted"><?= htmlspecialchars($exp['payment_method'] ?? 'Cash') ?></small></td>
                        <td class="text-danger fw-bold">₦<?= number_format($exp['amount'], 2) ?></td>
                        <td class="small text-muted"><?= htmlspecialchars($exp['description']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="expenseModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow" method="POST">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Record Expense</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Title/Item Name</label>
                    <input type="text" name="title" class="form-control" placeholder="e.g., Generator Fuel" required>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold">Amount (₦)</label>
                        <input type="number" step="0.01" name="amount" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold">Date</label>
                        <input type="date" name="expense_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold">Category</label>
                        <select name="category" class="form-select">
                            <option>Staff Salary</option>
                            <option>Maintenance</option>
                            <option>Utilities (Power/Water)</option>
                            <option>Stationery</option>
                            <option>Fuel/Logistics</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold">Payment Method</label>
                        <select name="payment_method" class="form-select">
                            <option value="Cash">Cash</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="POS">POS</option>
                            <option value="Cheque">Cheque</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Description (Optional)</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Briefly explain the expense..."></textarea>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="add_expense" class="btn btn-primary px-4 shadow">Save Expense</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Toggle sidebar on mobile
    document.querySelector('.btn-primary[data-bs-toggle="modal"]').insertAdjacentHTML('afterend', `
        <button class="btn btn-outline-primary btn-sm d-lg-none ms-2" onclick="document.getElementById('sidebar').classList.toggle('active')">
            <i class="bi bi-list"></i> Menu
        </button>
    `);
</script>
</body>
</html>