<?php
// 1. Error Reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';
require_once 'includes/functions.php'; // Ensure logAudit() is available

$message = "";
$student = null;
$bills = [];
$account_balance = 0; 

// --- 1. HANDLE FILTERS FOR OVERVIEW ---
$filter_month = $_GET['filter_month'] ?? '';
$filter_date = $_GET['filter_date'] ?? '';

$total_revenue = 0;
try {
    $overview_sql = "SELECT SUM(amount_paid) as total FROM payments WHERE 1=1";
    $params = [];
    if ($filter_month) {
        $overview_sql .= " AND DATE_FORMAT(payment_date, '%Y-%m') = ?";
        $params[] = $filter_month;
    }
    if ($filter_date) {
        $overview_sql .= " AND DATE(payment_date) = ?";
        $params[] = $filter_date;
    }
    $stmt_ov = $pdo->prepare($overview_sql);
    $stmt_ov->execute($params);
    $total_revenue = $stmt_ov->fetchColumn() ?: 0;
} catch (PDOException $e) {
    $total_revenue = 0; 
}

// --- 2. SEARCH FOR STUDENT ---
$search_query = $_GET['search'] ?? ''; 
if (!empty($search_query)) {
    $search = trim($search_query);
    $stmt = $pdo->prepare("SELECT s.*, c.name as class_name FROM students s 
                           JOIN classes c ON s.class_id = c.id 
                           WHERE s.admission_no = ? OR s.name = ? LIMIT 1");
    $stmt->execute([$search, $search]);
    $student = $stmt->fetch();

    if ($student) {
        $stmt_bills = $pdo->prepare("SELECT sb.*, 
                                     COALESCE(sess.name, 'All Periods') as session_name, 
                                     COALESCE(t.name, 'N/A') as term_name, 
                                     c.name as bill_class_name 
                                     FROM student_bills sb
                                     LEFT JOIN sessions sess ON sb.session_id = sess.id
                                     LEFT JOIN terms t ON sb.term_id = t.id
                                     LEFT JOIN students s ON sb.student_id = s.id
                                     LEFT JOIN classes c ON s.class_id = c.id
                                     WHERE sb.student_id = ? 
                                     ORDER BY (sb.item_name = 'Advance Credit') ASC, sb.id DESC");
        $stmt_bills->execute([$student['id']]);
        $bills = $stmt_bills->fetchAll();

        $stmt_bal = $pdo->prepare("SELECT SUM(balance) FROM student_bills WHERE student_id = ?");
        $stmt_bal->execute([$student['id']]);
        $account_balance = $stmt_bal->fetchColumn() ?: 0;
    }
}

// --- 3. PROCESS SETTLEMENT FROM ADVANCE CREDIT ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['settle_from_advance'])) {
    $student_id = $_POST['student_id'];
    try {
        $pdo->beginTransaction();
        $stmt_adv = $pdo->prepare("SELECT id, paid_amount, balance FROM student_bills WHERE student_id = ? AND item_name = 'Advance Credit' AND balance < 0 FOR UPDATE");
        $stmt_adv->execute([$student_id]);
        $adv_record = $stmt_adv->fetch();

        if ($adv_record) {
            $available_credit = abs($adv_record['balance']);
            $used_credit = 0;
            $stmt_debt = $pdo->prepare("SELECT id, item_name, total_amount, paid_amount, balance FROM student_bills WHERE student_id = ? AND balance > 0 AND item_name != 'Advance Credit' ORDER BY id ASC FOR UPDATE");
            $stmt_debt->execute([$student_id]);
            foreach ($stmt_debt->fetchAll() as $item) {
                if ($available_credit <= 0) break;
                $payment_to_apply = min($available_credit, $item['balance']);
                $new_paid = $item['paid_amount'] + $payment_to_apply;
                $new_balance = $item['total_amount'] - $new_paid;
                $pdo->prepare("UPDATE student_bills SET paid_amount = ?, balance = ?, status = ? WHERE id = ?")->execute([$new_paid, $new_balance, ($new_balance <= 0 ? 'paid' : 'partially_paid'), $item['id']]);
                $available_credit -= $payment_to_apply;
                $used_credit += $payment_to_apply;
            }
            if ($used_credit > 0) {
                $new_adv_paid = $adv_record['paid_amount'] - $used_credit;
                $pdo->prepare("UPDATE student_bills SET paid_amount = ?, balance = ? WHERE id = ?")->execute([$new_adv_paid, 0 - $new_adv_paid, $adv_record['id']]);
            }

            // AUDIT LOG FOR SETTLEMENT
            $st_name = $student['name'] ?? 'ID: '.$student_id;
            logAudit($pdo, "CREDIT SETTLEMENT", "Settled debts for $st_name using ₦" . number_format($used_credit, 2) . " from Advance Credit.");

            $pdo->commit();
            header("Location: payments.php?search=" . urlencode($search_query) . "&msg_type=success&msg_text=" . urlencode("Settled ₦" . number_format($used_credit, 2) . " from advance credit."));
            exit();
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        $message = "<div class='alert alert-danger'>Settlement Error: " . $e->getMessage() . "</div>";
    }
}

// --- 4. PROCESS NEW PAYMENT ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_now'])) {
    $initial_bill_id = $_POST['bill_id'] ?? null;
    $total_to_pay = (float)$_POST['amount'];
    $remaining_payment = $total_to_pay;
    $method = $_POST['method'];
    $ref = $_POST['reference'];
    $student_id = $_POST['student_id'];

    try {
        $pdo->beginTransaction();
        $history = $pdo->prepare("INSERT INTO payments (student_id, bill_id, amount_paid, payment_method, reference_no, payment_date) VALUES (?, ?, ?, ?, ?, NOW())");
        $history->execute([$student_id, $initial_bill_id, $remaining_payment, $method, $ref]);
        $last_payment_id = $pdo->lastInsertId();

        if ($initial_bill_id) {
            $stmt = $pdo->prepare("SELECT id, total_amount, paid_amount, balance FROM student_bills WHERE id = ? FOR UPDATE");
            $stmt->execute([$initial_bill_id]);
            $bill = $stmt->fetch();
            if ($bill && $bill['balance'] > 0) {
                $pay_amt = min($remaining_payment, $bill['balance']);
                $new_p = $bill['paid_amount'] + $pay_amt;
                $new_b = $bill['total_amount'] - $new_p;
                $pdo->prepare("UPDATE student_bills SET paid_amount = ?, balance = ?, status = ? WHERE id = ?")->execute([$new_p, $new_b, ($new_b <= 0 ? 'paid' : 'partially_paid'), $initial_bill_id]);
                $remaining_payment -= $pay_amt;
            }
        }

        if ($remaining_payment > 0) {
            $stmt_others = $pdo->prepare("SELECT id, total_amount, paid_amount, balance FROM student_bills WHERE student_id = ? AND balance > 0 AND item_name != 'Advance Credit' ORDER BY id ASC FOR UPDATE");
            $stmt_others->execute([$student_id]);
            foreach ($stmt_others->fetchAll() as $obill) {
                if ($remaining_payment <= 0) break;
                $pay_amt = min($remaining_payment, $obill['balance']);
                $new_p = $obill['paid_amount'] + $pay_amt;
                $new_b = $obill['total_amount'] - $new_p;
                $pdo->prepare("UPDATE student_bills SET paid_amount = ?, balance = ?, status = ? WHERE id = ?")->execute([$new_p, $new_b, ($new_b <= 0 ? 'paid' : 'partially_paid'), $obill['id']]);
                $remaining_payment -= $pay_amt;
            }
        }

        if ($remaining_payment > 0) {
            $stmt_adv = $pdo->prepare("SELECT id, paid_amount, balance FROM student_bills WHERE student_id = ? AND item_name = 'Advance Credit' LIMIT 1 FOR UPDATE");
            $stmt_adv->execute([$student_id]);
            $adv_bill = $stmt_adv->fetch();
            if (!$adv_bill) {
                $pdo->prepare("INSERT INTO student_bills (student_id, item_name, total_amount, paid_amount, balance, status) VALUES (?, 'Advance Credit', 0, ?, ?, 'paid')")->execute([$student_id, $remaining_payment, 0 - $remaining_payment]);
            } else {
                $new_p_adv = $adv_bill['paid_amount'] + $remaining_payment;
                $pdo->prepare("UPDATE student_bills SET paid_amount = ?, balance = ? WHERE id = ?")->execute([$new_p_adv, 0 - $new_p_adv, $adv_bill['id']]);
            }
        }

        // AUDIT LOG FOR NEW PAYMENT
        $st_name = $student['name'] ?? 'ID: '.$student_id;
        logAudit($pdo, "FEE PAYMENT", "Recorded payment of ₦" . number_format($total_to_pay, 2) . " for $st_name. Ref: $ref via $method");

        $pdo->commit();
        header("Location: payments.php?search=" . urlencode($search_query) . "&success=1&pid=$last_payment_id");
        exit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        $message = "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

if(isset($_GET['msg_text'])){
    $type = $_GET['msg_type'] ?? 'info';
    $message = "<div class='alert alert-$type alert-dismissible fade show shadow-sm' role='alert'>" . htmlspecialchars($_GET['msg_text']) . "<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
}
if(isset($_GET['success'])){
    $pid = $_GET['pid'] ?? '';
    $message = "<div class='alert alert-success alert-dismissible fade show shadow-sm' role='alert'><strong>Success!</strong> Payment processed. <a href='receipt.php?id=$pid' target='_blank' class='btn btn-sm btn-dark ms-3'><i class='bi bi-printer'></i> Print Receipt</a><button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; font-size: 0.82rem; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; overflow-y: auto; z-index: 1000; }
        .nav-link { color: #94a3b8; padding: 10px 20px; border-radius: 8px; margin: 2px 15px; text-decoration: none; display: flex; align-items: center; transition: 0.3s; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: white; }
        .nav-link.active { background: var(--primary-blue); color: white; font-weight: 600; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2); }
        .main-content { margin-left: 260px; padding: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        #suggestions { position: absolute; width: 100%; z-index: 1000; top: 100%; }
        .suggestion-item { cursor: pointer; padding: 12px; border-bottom: 1px solid #f1f5f9; background: white; transition: 0.2s; }
        .suggestion-item:hover { background: #eff6ff; color: #2563eb; }
        @media (max-width: 992px) { .sidebar { display: none; } .main-content { margin-left: 0; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <h6 class="fw-bold text-white mb-0">BGB GROUP | ACCOUNTS</h6>
    </div>
    <nav class="nav flex-column gap-1">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link active" href="payments.php"><i class="bi bi-credit-card me-2"></i> Payments</a>
        <a class="nav-link" href="sales.php"><i class="bi bi-cart-check me-2"></i> General Sales</a>
        <a class="nav-link" href="cashbook.php"><i class="bi bi-book me-2"></i> Cashbook</a>
        <a class="nav-link" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>
        <a class="nav-link" href="audit_trail.php"><i class="bi bi-shield-check me-2"></i> Audit Trail</a>
        <hr class="mx-3 text-secondary">
        <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">Student Payments</h3>
            <p class="text-muted small mb-0">Process tuition and reconcile balances</p>
        </div>
        <span class="badge bg-white text-dark border p-2 px-3 rounded-pill shadow-sm"><?= date('l, d M Y') ?></span>
    </div>
    
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card p-4 bg-primary text-white border-0 h-100 shadow">
                <p class="small text-uppercase mb-1 opacity-75 fw-bold">Revenue Collected</p>
                <h2 class="fw-bold mb-0">₦<?= number_format($total_revenue, 2) ?></h2>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card p-4 h-100">
                <form method="GET" class="row g-2 align-items-end">
                    <div class="col-md-5">
                        <label class="small fw-bold text-muted">Filter Month</label>
                        <input type="month" name="filter_month" class="form-control" value="<?= htmlspecialchars($filter_month ?? '') ?>">
                    </div>
                    <div class="col-md-5">
                        <label class="small fw-bold text-muted">Filter Date</label>
                        <input type="date" name="filter_date" class="form-control" value="<?= htmlspecialchars($filter_date ?? '') ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-dark w-100">Filter</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="mb-4">
        <?= $message ?>
    </div>

    <div class="card p-4 mb-4 position-relative">
        <form method="GET" id="searchForm">
            <label class="form-label fw-bold">Find Student</label>
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0 rounded-start-pill text-muted ps-3"><i class="bi bi-search"></i></span>
                <input type="text" name="search" id="studentSearch" class="form-control border-start-0 rounded-end-pill py-2" placeholder="Search name or admission number..." autocomplete="off" value="<?= htmlspecialchars($search_query ?? '') ?>" required>
            </div>
            <div id="suggestions" class="list-group shadow"></div>
        </form>
    </div>

    <?php if ($student): ?>
    <div class="row">
        <div class="col-md-3">
            <div class="card p-4 text-center border-0 mb-4 h-100 shadow-sm">
                <div class="mx-auto mb-3 bg-light rounded-circle d-flex align-items-center justify-content-center" style="width: 70px; height: 70px;">
                    <i class="bi bi-person text-primary fs-3"></i>
                </div>
                <h6 class="fw-bold mb-1"><?= htmlspecialchars($student['name'] ?? '') ?></h6>
                <p class="text-muted small mb-3"><?= htmlspecialchars($student['admission_no'] ?? '') ?></p>
                <p class="badge bg-secondary mb-3"><?= htmlspecialchars($student['class_name'] ?? '') ?></p>
                
                <hr>
                
                <p class="small text-uppercase fw-bold text-muted mb-1">Total Account Balance</p>
                <?php if ($account_balance > 0): ?>
                    <h3 class="fw-bold text-danger">₦<?= number_format($account_balance, 2) ?></h3>
                    <span class="badge bg-danger-subtle text-danger rounded-pill px-3">UNPAID DEBT</span>
                <?php elseif ($account_balance < 0): ?>
                    <h3 class="fw-bold text-success">₦<?= number_format(abs($account_balance), 2) ?></h3>
                    <span class="badge bg-success-subtle text-success rounded-pill px-3">CREDIT BALANCE</span>
                <?php else: ?>
                    <h3 class="fw-bold text-primary">₦0.00</h3>
                    <span class="badge bg-primary-subtle text-primary rounded-pill px-3">CLEARED</span>
                <?php endif; ?>

                <div class="mt-4 pt-3 border-top">
                    <?php if ($account_balance < 0): ?>
                        <form method="POST" onsubmit="return confirm('Use Advance Credit to balance all outstanding bills?');">
                            <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                            <button type="submit" name="settle_from_advance" class="btn btn-primary btn-sm w-100 rounded-pill shadow-sm">
                                <i class="bi bi-arrow-repeat me-1"></i> Settle from Advance
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <div class="card p-4 h-100">
                <h6 class="fw-bold mb-4 d-flex align-items-center">
                    <i class="bi bi-list-check me-2 text-primary"></i> Billing History
                </h6>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="bg-light">
                            <tr class="small text-uppercase text-secondary">
                                <th>Academic Period</th>
                                <th>Class</th>
                                <th>Fee Item</th>
                                <th>Total Bill</th>
                                <th>Balance</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bills as $bill): ?>
                            <tr>
                                <td class="small">
                                    <span class="fw-bold"><?= htmlspecialchars($bill['session_name']) ?></span><br>
                                    <span class="text-muted"><?= htmlspecialchars($bill['term_name']) ?></span>
                                </td>
                                <td class="small"><?= htmlspecialchars($bill['bill_class_name'] ?? 'N/A') ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($bill['item_name'] ?? '') ?></td>
                                <td>₦<?= number_format($bill['total_amount'], 2) ?></td>
                                <td>
                                    <?php if($bill['balance'] > 0): ?>
                                        <span class="text-danger fw-bold">₦<?= number_format($bill['balance'], 2) ?></span>
                                    <?php elseif($bill['balance'] < 0): ?>
                                        <span class="text-success fw-bold">₦<?= number_format(abs($bill['balance']), 2) ?> (Adv)</span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-success border">Paid</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group">
                                        <?php if($bill['balance'] > 0): ?>
                                        <button class="btn btn-sm btn-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#payModal<?= $bill['id'] ?>">
                                            Pay
                                        </button>
                                        <?php endif; ?>
                                        <a href="receipt_summary.php?bill_id=<?= $bill['id'] ?>&student_id=<?= $student['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary ms-1 rounded-pill" title="Print Status">
                                            <i class="bi bi-printer"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            
                            <div class="modal fade" id="payModal<?= $bill['id'] ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content border-0 shadow">
                                        <form method="POST">
                                            <input type="hidden" name="bill_id" value="<?= $bill['id'] ?>">
                                            <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                            <div class="modal-header border-0 bg-light pb-2">
                                                <h6 class="fw-bold mb-0">Pay for <?= htmlspecialchars($bill['item_name']) ?></h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body p-4">
                                                <div class="mb-3">
                                                    <label class="form-label small fw-bold">Amount to Pay (₦)</label>
                                                    <input type="number" step="0.01" name="amount" class="form-control form-control-lg fw-bold text-primary" value="<?= $bill['balance'] ?>" required>
                                                </div>
                                                <div class="row g-2">
                                                    <div class="col-6">
                                                        <label class="small fw-bold">Method</label>
                                                        <select name="method" class="form-select" required>
                                                            <option value="Cash">Cash</option>
                                                            <option value="Bank Transfer">Bank Transfer</option>
                                                            <option value="POS">POS</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-6">
                                                        <label class="small fw-bold">Receipt No.</label>
                                                        <input type="text" name="reference" class="form-control" placeholder="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-0 pt-0">
                                                <button type="submit" name="pay_now" class="btn btn-primary w-100 py-2">Record Payment</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function() {
    $('#studentSearch').on('input', function() {
        let query = $(this).val();
        if (query.length > 2) {
            $.ajax({
                url: 'ajax_search_students.php',
                method: 'POST',
                data: { query: query },
                success: function(data) { $('#suggestions').html(data); }
            });
        } else { $('#suggestions').empty(); }
    });
    $(document).on('click', '.suggestion-item', function() {
        $('#studentSearch').val($(this).data('name'));
        $('#searchForm').submit();
    });
});
</script>
</body>
</html>