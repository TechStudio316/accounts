<?php
session_start();
// Protect the page - Only Admin and Accountant roles allowed
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/includes/db.php'; 

// --- HANDLE FILTERS ---
$filter_session = $_GET['session'] ?? '';
$filter_term = $_GET['term'] ?? '';
$filter_class = $_GET['class'] ?? 'all';
$filter_date = $_GET['filter_date'] ?? '';

try {
    // 1. Fetch School Info for Branding
    $school = $pdo->query("SELECT * FROM school_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $school_name = $school['name'] ?? 'SchoolRMS';
    $school_logo = "/storage/logos/school-1.png";

    // 2. Fetch Classes/Sessions/Terms for filters
    $classes = $pdo->query("SELECT id, name, section FROM classes ORDER BY name ASC")->fetchAll();
    $sessions = $pdo->query("SELECT id, name FROM sessions ORDER BY name DESC")->fetchAll();
    $term_data = $pdo->query("SELECT id, term_id FROM term_activations ORDER BY term_id ASC")->fetchAll();
    $term_names = [1 => "First Term", 2 => "Second Term", 3 => "Third Term"];

    // 3. Financial Stats from Unified Cashbook
    $collate_fix = " COLLATE utf8mb4_unicode_ci";
    
    $date_clause = $filter_date ? " WHERE DATE(date) = '$filter_date' $collate_fix" : "";
    
    // Total Income (Revenue)
    $income_q = "SELECT SUM(amount) FROM unified_cashbook" . ($filter_date ? $date_clause . " AND type='Income'" : " WHERE type='Income'");
    $total_income = $pdo->query($income_q)->fetchColumn() ?: 0;
    
    // Total Expenses
    $expense_q = "SELECT SUM(amount) FROM unified_cashbook" . ($filter_date ? $date_clause . " AND type='Expense'" : " WHERE type='Expense'");
    $total_expenses = $pdo->query($expense_q)->fetchColumn() ?: 0;
    
    $net_cash = $total_income - $total_expenses;

    // --- TODAY'S SUMMARY (Forced Collation) ---
    $today = date('Y-m-d');
    $today_income = $pdo->query("SELECT SUM(amount) FROM unified_cashbook WHERE type='Income' AND DATE(date) = '$today' $collate_fix")->fetchColumn() ?: 0;
    $today_expense = $pdo->query("SELECT SUM(amount) FROM unified_cashbook WHERE type='Expense' AND DATE(date) = '$today' $collate_fix")->fetchColumn() ?: 0;

    // 4. Student & Debt Stats
    /** * FIX: Counts students whose status is either NULL, empty, or NOT 'left'.
     * This ensures the 200+ students with NULL status are included.
     */
    $total_students = $pdo->query("SELECT COUNT(*) FROM students WHERE status IS NULL OR status = '' OR LOWER(status) != 'left'")->fetchColumn() ?: 0;
    
    $outstanding_debt = $pdo->query("SELECT SUM(balance) FROM student_bills WHERE balance > 0")->fetchColumn() ?: 0;
    $total_defaulters = $pdo->query("SELECT COUNT(DISTINCT student_id) FROM student_bills WHERE balance > 0")->fetchColumn() ?: 0;

    // 5. Chart Data: Monthly Income vs Expenses (Last 6 Months)
    $chart_labels = [];
    $income_data = [];
    $expense_data = [];
    for ($i = 5; $i >= 0; $i--) {
        $month = date('Y-m', strtotime("-$i months"));
        $chart_labels[] = date('M', strtotime("-$i months"));
        
        $inc = $pdo->query("SELECT SUM(amount) FROM unified_cashbook WHERE type='Income' AND DATE_FORMAT(date, '%Y-%m') = '$month' $collate_fix")->fetchColumn() ?: 0;
        $exp = $pdo->query("SELECT SUM(amount) FROM unified_cashbook WHERE type='Expense' AND DATE_FORMAT(date, '%Y-%m') = '$month' $collate_fix")->fetchColumn() ?: 0;
        
        $income_data[] = $inc;
        $expense_data[] = $exp;
    }

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | <?= htmlspecialchars($school_name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --sidebar-bg: #0f172a; --primary-blue: #2563eb; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: var(--sidebar-bg); color: white; transition: 0.3s; z-index: 1000; overflow-y: auto; }
        .main-content { margin-left: 260px; padding: 30px; transition: 0.3s; }
        .stat-card { border: none; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); transition: transform 0.2s; position: relative; overflow: hidden; }
        .stat-card:hover { transform: translateY(-5px); }
        .nav-link { color: #94a3b8; padding: 10px 20px; border-radius: 8px; margin: 2px 15px; text-decoration: none; display: block; font-size: 0.9rem; }
        .nav-link:hover { background: rgba(255,255,255,0.05); color: white; }
        .nav-link.active { background: var(--primary-blue); color: white; }
        .filter-bar { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .menu-label { font-size: 0.7rem; font-weight: 700; color: #475569; margin: 15px 25px 5px; text-transform: uppercase; letter-spacing: 1px; }
        
        @media (max-width: 992px) { 
            .sidebar { left: -260px; } 
            .main-content { margin-left: 0; padding: 15px; } 
            .sidebar.active { left: 0; } 
            .header-info { text-align: left; margin-top: 10px; }
        }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <img src="<?= $school_logo ?>" alt="Logo" style="height: 60px; width: 60px; object-fit: contain;">
        <h6 class="mt-3 fw-bold text-truncate"><?= htmlspecialchars($school_name) ?></h6>
    </div>
    <nav class="nav flex-column mb-5">
        <a class="nav-link active" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        
        <div class="menu-label">Finance & Bursary</div>
        <a class="nav-link" href="payments.php"><i class="bi bi-credit-card me-2"></i> Record Payment</a>
        <a class="nav-link" href="billing.php"><i class="bi bi-receipt-cutoff me-2"></i> Fee Management</a>
        <a class="nav-link" href="bill_items.php"><i class="bi bi-list-stars me-2"></i> Bill Items</a>
        <a class="nav-link" href="expenses.php"><i class="bi bi-cash-stack me-2"></i> Expenses</a>

        <div class="menu-label">General Ledger</div>
        <a class="nav-link" href="cashbook.php"><i class="bi bi-book me-2"></i> Cashbook</a>
        <a class="nav-link" href="sales.php"><i class="bi bi-cart-check me-2"></i> Sales (Uniforms/Books)</a>
        
        <div class="menu-label">Debt Recovery</div>
        <a class="nav-link" href="defaulters.php"><i class="bi bi-exclamation-triangle me-2"></i> Defaulters List</a>
        <a class="nav-link" href="import_arrears.php"><i class="bi bi-person-plus me-2"></i> Import Arrears</a>
        <a class="nav-link" href="bulk_import_arrears.php"><i class="bi bi-file-earmark-spreadsheet me-2"></i> Bulk Import</a>
        
        <div class="menu-label">Reports & Audit</div>
        <a class="nav-link" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Financial Analysis</a>
        <a class="nav-link" href="audit_trail.php"><i class="bi bi-shield-check me-2"></i> Audit Trail</a>
        
        <div class="menu-label">Administration</div>
        <a class="nav-link" href="school_settings.php"><i class="bi bi-gear me-2"></i> School Settings</a>
        <a class="nav-link text-danger mt-4" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Financial Dashboard</h3>
            <p class="text-muted mb-0">Welcome, <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?> (<?= ucfirst($_SESSION['role'] ?? 'Staff') ?>)</p>
        </div>
        <div class="header-info d-flex align-items-center gap-3">
            <div class="text-md-end">
                <p class="mb-0 fw-bold text-primary"><i class="bi bi-calendar3 me-2"></i><?= date('l, jS F Y') ?></p>
                <small class="text-muted">School Management Portal</small>
            </div>
            <button class="btn btn-white d-lg-none shadow-sm" onclick="document.getElementById('sidebar').classList.toggle('active')">
                <i class="bi bi-list"></i>
            </button>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm p-3 bg-white" style="border-radius: 12px;">
                <div class="row align-items-center">
                    <div class="col-md-3 border-end">
                        <small class="text-uppercase fw-bold text-muted">Today's Inflow</small>
                        <h5 class="text-success fw-bold mb-0">₦<?= number_format($today_income, 2) ?></h5>
                    </div>
                    <div class="col-md-3 border-end ps-md-4">
                        <small class="text-uppercase fw-bold text-muted">Today's Outflow</small>
                        <h5 class="text-danger fw-bold mb-0">₦<?= number_format($today_expense, 2) ?></h5>
                    </div>
                    <div class="col-md-6 ps-md-4">
                        <div class="progress mt-2" style="height: 8px;">
                            <?php 
                                $total_today = $today_income + $today_expense;
                                $inc_perc = ($total_today > 0) ? ($today_income / $total_today) * 100 : 0;
                            ?>
                            <div class="progress-bar bg-success" style="width: <?= $inc_perc ?>%"></div>
                            <div class="progress-bar bg-danger" style="width: <?= 100 - $inc_perc ?>%"></div>
                        </div>
                        <small class="text-muted mt-1 d-block">Cash Flow Ratio (Income vs Expense)</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="filter-bar mb-4">
        <form class="row g-3" method="GET">
            <div class="col-md-2 col-6">
                <label class="form-label small fw-bold text-secondary">SESSION</label>
                <select name="session" class="form-select border-light bg-light">
                    <?php foreach ($sessions as $session): ?>
                        <option value="<?= $session['id'] ?>" <?= $filter_session == $session['id'] ? 'selected' : '' ?>><?= htmlspecialchars($session['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 col-6">
                <label class="form-label small fw-bold text-secondary">TERM</label>
                <select name="term" class="form-select border-light bg-light">
                    <?php foreach ($term_data as $term): ?>
                        <option value="<?= $term['term_id'] ?>" <?= $filter_term == $term['term_id'] ? 'selected' : '' ?>>
                            <?= $term_names[$term['term_id']] ?? "Unknown Term" ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 col-12">
                <label class="form-label small fw-bold text-secondary">CLASS</label>
                <select name="class" class="form-select border-light bg-light">
                    <option value="all">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?= $class['id'] ?>" <?= $filter_class == $class['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($class['name']) ?> (<?= htmlspecialchars($class['section']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 col-12">
                <label class="form-label small fw-bold text-secondary">SPECIFIC DATE</label>
                <input type="date" name="filter_date" class="form-control border-light bg-light" value="<?= $filter_date ?>">
            </div>
            <div class="col-md-2 col-12 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100 py-2"><i class="bi bi-filter me-2"></i>Update</button>
            </div>
        </form>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-sm-6 col-md-3">
            <div class="card stat-card bg-primary text-white p-4">
                <p class="small fw-bold mb-1 opacity-75">TOTAL REVENUE</p>
                <h3 class="fw-bold mb-0">₦<?= number_format($total_income, 2) ?></h3>
                <i class="bi bi-graph-up-arrow position-absolute bottom-0 end-0 m-3 opacity-25 h2"></i>
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="card stat-card bg-danger text-white p-4">
                <p class="small fw-bold mb-1 opacity-75">OUTSTANDING DEBT</p>
                <h3 class="fw-bold mb-0">₦<?= number_format($outstanding_debt, 2) ?></h3>
                <i class="bi bi-exclamation-circle position-absolute bottom-0 end-0 m-3 opacity-25 h2"></i>
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="card stat-card bg-success text-white p-4">
                <p class="small fw-bold mb-1 opacity-75">NET CASH POSITION</p>
                <h3 class="fw-bold mb-0">₦<?= number_format($net_cash, 2) ?></h3>
                <i class="bi bi-safe position-absolute bottom-0 end-0 m-3 opacity-25 h2"></i>
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <div class="card stat-card bg-dark text-white p-4">
                <p class="small fw-bold mb-1 opacity-75">ACTIVE STUDENTS</p>
                <h3 class="fw-bold mb-0"><?= number_format($total_students) ?></h3>
                <i class="bi bi-people position-absolute bottom-0 end-0 m-3 opacity-25 h2"></i>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8 col-12">
            <div class="card border-0 shadow-sm p-4" style="border-radius: 16px;">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-bold mb-0">Income vs Expenditure</h5>
                    <span class="badge bg-light text-dark">Last 6 Months</span>
                </div>
                <div style="position: relative; height:300px;">
                    <canvas id="financeChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-12">
            <div class="card border-0 shadow-sm p-4 mb-4" style="border-radius: 16px;">
                <h5 class="fw-bold mb-3">Quick Navigation</h5>
                <div class="list-group list-group-flush">
                    <a href="cashbook.php" class="list-group-item list-group-item-action border-0 px-0 d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-book me-2 text-primary"></i>View Cashbook Ledger</span>
                        <i class="bi bi-chevron-right small text-muted"></i>
                    </a>
                    <a href="defaulters.php" class="list-group-item list-group-item-action border-0 px-0 d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-person-x me-2 text-danger"></i>Manage Defaulters</span>
                        <i class="bi bi-chevron-right small text-muted"></i>
                    </a>
                    <a href="expenses.php" class="list-group-item list-group-item-action border-0 px-0 d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-cart-plus me-2 text-warning"></i>Record Expense</span>
                        <i class="bi bi-chevron-right small text-muted"></i>
                    </a>
                </div>
            </div>

            <div class="card border-0 shadow-sm p-4 bg-warning bg-opacity-10" style="border-radius: 16px;">
                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-bell-fill me-2"></i>Defaulter Alert</h6>
                <p class="small text-dark mb-4">There are currently <strong><?= $total_defaulters ?></strong> students with unpaid balances.</p>
                <a href="defaulters.php" class="btn btn-dark btn-sm w-100 rounded-pill">View Defaulter List</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('financeChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($chart_labels) ?>,
            datasets: [
                {
                    label: 'Income (₦)',
                    data: <?= json_encode($income_data) ?>,
                    backgroundColor: '#2563eb',
                    borderRadius: 5
                },
                {
                    label: 'Expenditure (₦)',
                    data: <?= json_encode($expense_data) ?>,
                    backgroundColor: '#f43f5e',
                    borderRadius: 5
                }
            ]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false,
            plugins: { 
                legend: { position: 'top' } 
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
</script>
</body>
</html>