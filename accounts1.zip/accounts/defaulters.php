<?php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'accountant'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/db.php';

$sms_message = "";

// --- SMS SENDING LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_sms'])) {
    $parent_parent_info = $_POST['parent_info'];
    $student_name = $_POST['student_name'];
    $debt_amount = $_POST['debt_amount'];

    if (!empty($parent_parent_info) && $parent_parent_info !== 'N/A') {
        // Format message
        $text = "Dear Parent, this is a reminder that " . $student_name . " has an outstanding school fee balance of N" . number_format($debt_amount, 2) . ". Please kindly make payment. Thank you.";
        
        // PLACE YOUR SMS API CODE HERE (Twilio, BulkSMS, etc.)
        // Example: $result = my_sms_provider_function($parent_parent_info, $text);
        
        $sms_message = "<div class='alert alert-success alert-dismissible fade show no-print' role='alert'>
                            <i class='bi bi-check-circle me-2'></i> Reminder sent to $student_name's parent ($parent_parent_info).
                            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        </div>";
    } else {
        $sms_message = "<div class='alert alert-warning alert-dismissible fade show no-print' role='alert'>
                            <i class='bi bi-exclamation-triangle me-2'></i> Cannot send SMS: No valid parent_info number found.
                            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        </div>";
    }
}

// --- 1. SET FILTERS ---
$class_id = $_GET['class_id'] ?? '';
$min_debt = $_GET['min_debt'] ?? 1;

$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll();

function tableColumns(PDO $pdo, string $table): array {
    $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
    return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'Field');
}

function firstExistingColumn(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) {
        if (in_array($candidate, $columns, true)) {
            return $candidate;
        }
    }

    return null;
}

$studentColumns = tableColumns($pdo, 'students');
$studentNameCol = firstExistingColumn($studentColumns, ['full_name', 'name', 'student_name']);
$admissionCol = firstExistingColumn($studentColumns, ['admission_no', 'reg_no', 'student_no']);
$parentContactCol = firstExistingColumn($studentColumns, ['parent_phone', 'guardian_phone', 'parent_info', 'phone']);

$studentNameExpr = $studentNameCol ? "s.`$studentNameCol`" : "CONCAT('Student #', s.id)";
$admissionExpr = $admissionCol ? "s.`$admissionCol`" : "''";
$parentContactExpr = $parentContactCol ? "s.`$parentContactCol`" : "''";

// --- 2. FETCH DEFAULTERS ---
$sql = "SELECT s.id as student_id,
               $studentNameExpr as name,
               $admissionExpr as admission_no,
               $parentContactExpr as parent_parent_info,
               c.name as class_name, 
               SUM(sb.balance) as total_owed,
               COUNT(sb.id) as unpaid_bill_count
        FROM students s
        JOIN classes c ON s.class_id = c.id
        JOIN student_bills sb ON s.id = sb.student_id
        WHERE sb.balance > 0";

$params = [];
if ($class_id) {
    $sql .= " AND s.class_id = ?";
    $params[] = $class_id;
}

$sql .= " GROUP BY s.id, name, admission_no, parent_parent_info, class_name HAVING total_owed >= ? ORDER BY total_owed DESC";
$params[] = $min_debt;

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $defaulters = $stmt->fetchAll();
    
    $total_debt_value = 0;
    foreach($defaulters as $d) $total_debt_value += $d['total_owed'];
    
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Defaulters List | SchoolRMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: #f1f5f9; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: #0f172a; color: white; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        @media print {
            .sidebar, .btn, .filters, .no-print { display: none !important; }
            .main-content { margin-left: 0; padding: 0; }
            .card { box-shadow: none; border: 1px solid #eee; }
        }
    </style>
</head>
<body>

<div class="sidebar no-print">
    <div class="p-4 text-center border-bottom border-secondary mb-3">
        <h6 class="fw-bold">SchoolRMS | Recovery</h6>
    </div>
    <nav class="nav flex-column px-3">
        <a class="nav-link text-white-50" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link text-white-50" href="reports.php"><i class="bi bi-graph-up-arrow me-2"></i> Financial Reports</a>
        <a class="nav-link text-white fw-bold active" href="defaulters.php"><i class="bi bi-exclamation-triangle me-2"></i> Defaulters List</a>
        <a class="nav-link text-white-50" href="payments.php"><i class="bi bi-credit-card me-2"></i> Record Payment</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold">Defaulters & Debt Recovery</h3>
            <p class="text-muted">Manage outstanding balances and send reminders.</p>
        </div>
        <div class="no-print">
            <button class="btn btn-dark" onclick="window.print()"><i class="bi bi-printer me-2"></i> Print List</button>
        </div>
    </div>

    <?= $sms_message ?>

    <div class="card p-4 mb-4 filters no-print">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="small fw-bold">Filter by Class</label>
                <select name="class_id" class="form-select">
                    <option value="">All Classes</option>
                    <?php foreach($classes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $class_id == $c['id'] ? 'selected' : '' ?>><?= $c['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="small fw-bold">Min. Debt Amount (₦)</label>
                <input type="number" name="min_debt" class="form-control" value="<?= $min_debt ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">Apply Filter</button>
            </div>
        </form>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card p-4 bg-danger text-white">
                <p class="small text-uppercase mb-1 opacity-75">Total Outstanding Recovery</p>
                <h2 class="fw-bold mb-0">₦<?= number_format($total_debt_value, 2) ?></h2>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card p-4 bg-white">
                <p class="small text-uppercase mb-1 text-muted">Total Defaulters Found</p>
                <h2 class="fw-bold mb-0 text-dark"><?= count($defaulters) ?> Students</h2>
            </div>
        </div>
    </div>

    <div class="card p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Student Name</th>
                        <th>Adm No.</th>
                        <th>Class</th>
                        <th>Parent parent_info</th>
                        <th class="text-end">Total Owed</th>
                        <th class="no-print">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($defaulters)): ?>
                        <tr><td colspan="6" class="text-center py-4">No defaulters found based on your filters.</td></tr>
                    <?php endif; ?>
                    <?php foreach($defaulters as $row): ?>
                    <tr>
                        <td>
                            <div class="fw-bold"><?= htmlspecialchars($row['name']) ?></div>
                            <small class="text-muted"><?= $row['unpaid_bill_count'] ?> pending bills</small>
                        </td>
                        <td><?= htmlspecialchars($row['admission_no']) ?></td>
                        <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['class_name']) ?></span></td>
                        <td>
                            <a href="tel:<?= $row['parent_parent_info'] ?>" class="text-decoration-none">
                                <i class="bi bi-telephone me-1"></i> <?= htmlspecialchars($row['parent_parent_info'] ?? 'N/A') ?>
                            </a>
                        </td>
                        <td class="text-end fw-bold text-danger">
                            ₦<?= number_format($row['total_owed'], 2) ?>
                        </td>
                        <td class="no-print">
                            <div class="btn-group">
                                <a href="payments.php?search=<?= urlencode($row['admission_no'] ?? '') ?>" class="btn btn-sm btn-outline-dark">
                                    Record Pay
                                </a>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="parent_info" value="<?= htmlspecialchars($row['parent_parent_info'] ?? '') ?>">
                                    <input type="hidden" name="student_name" value="<?= htmlspecialchars($row['name']) ?>">
                                    <input type="hidden" name="debt_amount" value="<?= $row['total_owed'] ?>">
                                    <button type="submit" name="send_sms" class="btn btn-sm btn-outline-primary" title="Send SMS Reminder">
                                        <i class="bi bi-chat-left-text"></i> SMS
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
