<?php
session_start();
require_once __DIR__ . '/includes/db.php';

// Security check
if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit();
}

if (isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];
    
    try {
        $stmt = $pdo->prepare("SELECT id, name, admission_no FROM students WHERE class_id = ? ORDER BY name ASC");
        $stmt->execute([$class_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        header('Content-Type: application/json');
        echo json_encode($students);
    } catch (PDOException $e) {
        echo json_encode(["error" => $e->getMessage()]);
    }
} else {
    echo json_encode([]);
}